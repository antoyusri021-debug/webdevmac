/**
 * js/temaoverlay.js
 * Pengelola preset tema dan modal daftar overlay.
 */

// Sesuaikan satu baris ini jika folder overlay kamu berada di lokasi berbeda.
const OVERLAY_BASE_PATH = '/themes/overlaytema/kemerdekaan';

const themeOverlayData = {
    kemerdekaan: {
        title: 'KEMERDEKAAN INDONESIA OVERLAY BUNDLE',
        desc: 'Kumpulan 10 overlay interaktif bertema Kemerdekaan Indonesia untuk live streaming kamu.',
        items: [
            { id: 'chatbox', name: 'ChatBox', icon: 'fa-comments', file: 'chatbox.html' },
            { id: 'chatdock', name: 'ChatDock', icon: 'fa-message', file: 'chatdock.html' },
            { id: 'clock', name: 'Jam Digital', icon: 'fa-clock', file: 'clock.html' },
            { id: 'top-like', name: 'Top Like', icon: 'fa-heart', file: 'top-like.html' },
            { id: 'top-gift', name: 'Top Gift', icon: 'fa-trophy', file: 'top-gift.html' },
            { id: 'viewers', name: 'Jumlah View', icon: 'fa-eye', file: 'viewers.html' },
            { id: 'alert-join', name: 'Alert Join', icon: 'fa-user-plus', file: 'alert-join.html' },
            { id: 'alert-share', name: 'Alert Share', icon: 'fa-share-nodes', file: 'alert-share.html' },
            { id: 'alert-follow', name: 'Alert Follow', icon: 'fa-bell', file: 'alert-follow.html' },
            { id: 'alert-gift', name: 'Alert Gift', icon: 'fa-gift', file: 'alert-gift.html' }
        ]
    }
};

function getOverlayOrigin() {
    const currentOrigin = window.location.origin;

    // Saat dibuka lewat file://, iframe tidak bisa memakai file URL untuk server lokal.
    if (!currentOrigin || currentOrigin === 'null' || window.location.protocol === 'file:') {
        return 'http://localhost:3000';
    }

    return currentOrigin;
}

function getOverlayUrl(fileName) {
    const basePath = OVERLAY_BASE_PATH.replace(/\/+$/, '');
    return new URL(`${basePath}/${fileName}`, getOverlayOrigin()).href;
}

function openThemeModal(themeKey) {
    const theme = themeOverlayData[themeKey];
    if (!theme) {
        console.warn(`Preset tema tidak ditemukan: ${themeKey}`);
        return;
    }

    const modalTitle = document.getElementById('modal-theme-title');
    const modalDesc = document.getElementById('modal-theme-desc');
    const container = document.getElementById('overlay-cards-container');
    const modal = document.getElementById('theme-modal');

    if (modalTitle) modalTitle.textContent = theme.title;
    if (modalDesc) modalDesc.textContent = theme.desc;

    if (container) {
        container.replaceChildren();

        theme.items.forEach((item) => {
            const overlayUrl = getOverlayUrl(item.file);
            const iframeUrl = `${overlayUrl}?preview=true`;

            const card = document.createElement('div');
            card.className = 'overlay-item-card';
            card.innerHTML = `
                <div class="preview-box" style="position: relative; width: 100%; height: 160px; overflow: hidden; background: #0b0f19; border-radius: 8px;">
                    <iframe
                        src="${iframeUrl}"
                        class="preview-iframe"
                        scrolling="no"
                        title="Preview ${item.name}"
                        loading="lazy"
                        style="width: 200%; height: 200%; border: none; position: absolute; top: 0; left: 0; transform: scale(0.5); transform-origin: top left; pointer-events: none;">
                    </iframe>
                </div>
                <div class="overlay-item-info" style="display: flex; align-items: center; gap: 8px; margin-top: 10px;">
                    <i class="fa-solid ${item.icon}" aria-hidden="true" style="color: #c8102e;"></i>
                    <h4 style="margin: 0; color: #fff; font-size: 0.95rem;">${item.name}</h4>
                </div>
                <button type="button" class="btn-copy-url">
                    <i class="fa-solid fa-copy" aria-hidden="true"></i>
                    Salin Link Overlay
                </button>
            `;

            const copyButton = card.querySelector('.btn-copy-url');
            if (copyButton) {
                copyButton.addEventListener('click', () => {
                    executeCopyLink(overlayUrl, copyButton);
                });
            }

            container.appendChild(card);
        });
    }

    if (modal) modal.style.display = 'flex';
}

function closeThemeModal() {
    const modal = document.getElementById('theme-modal');
    if (modal) modal.style.display = 'none';

    const container = document.getElementById('overlay-cards-container');
    if (container) container.replaceChildren();
}

function executeCopyLink(urlText, button) {
    if (!urlText) return;

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(urlText)
            .then(() => showSuccessEffect(button))
            .catch(() => fallbackCopy(urlText, button));
        return;
    }

    fallbackCopy(urlText, button);
}

function fallbackCopy(text, button) {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';
    textarea.style.top = '0';
    document.body.appendChild(textarea);
    textarea.select();

    let copied = false;
    try {
        copied = document.execCommand('copy');
    } catch (error) {
        console.warn('Fallback copy gagal:', error);
    } finally {
        textarea.remove();
    }

    if (copied) {
        showSuccessEffect(button);
    } else {
        showToastOrNotification('Link gagal disalin. Silakan salin secara manual.');
    }
}

function showSuccessEffect(button) {
    if (button) {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fa-solid fa-check" aria-hidden="true"></i> Tersalin!';
        button.style.backgroundColor = '#22c55e';
        button.style.color = '#fff';

        setTimeout(() => {
            button.innerHTML = originalText;
            button.style.backgroundColor = '';
            button.style.color = '';
        }, 2000);
    }

    showToastOrNotification('Link overlay berhasil disalin dan siap digunakan.');
}

function showToastOrNotification(message) {
    if (typeof showToast === 'function') {
        showToast(message);
    } else if (typeof showNotification === 'function') {
        showNotification(message);
    } else {
        console.info(message);
    }
}

// Menutup modal saat tombol Escape ditekan atau area luar modal diklik.
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closeThemeModal();
});

document.addEventListener('click', (event) => {
    const modal = document.getElementById('theme-modal');
    if (modal && event.target === modal) closeThemeModal();
});
