const fs = require('fs');
const path = require('path');

// Jalankan dari folder yang berisi folder StikerGift.
const stickersRoot = path.resolve(__dirname, 'StikerGift');
const outputFile = path.join(stickersRoot, 'stickers.json');

if (!fs.existsSync(stickersRoot)) {
    console.error(`Folder tidak ditemukan: ${stickersRoot}`);
    process.exit(1);
}

const encodePath = (value) => value
    .split(path.sep)
    .map(segment => encodeURIComponent(segment))
    .join('/');

const folders = fs.readdirSync(stickersRoot, { withFileTypes: true })
    .filter(entry => entry.isDirectory())
    .sort((a, b) => {
        const coinsA = Number((a.name.match(/\d+/) || ['Infinity'])[0]);
        const coinsB = Number((b.name.match(/\d+/) || ['Infinity'])[0]);
        return coinsA - coinsB || a.name.localeCompare(b.name);
    });

const stickers = [];

for (const folder of folders) {
    const folderPath = path.join(stickersRoot, folder.name);
    const files = fs.readdirSync(folderPath, { withFileTypes: true })
        .filter(entry => entry.isFile() && /\.webp$/i.test(entry.name))
        .sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

    for (const file of files) {
        // URL dibuat relatif terhadap folder kerja saat command dijalankan.
        // Dari root proyek hasilnya: js/StikerGift/nama-file.webp
        const relativePath = path.relative(process.cwd(), path.join(folderPath, file.name));
        stickers.push({
            name: path.basename(file.name, path.extname(file.name)),
            coinFolder: folder.name,
            url: encodePath(relativePath)
        });
    }
}

fs.writeFileSync(outputFile, `${JSON.stringify(stickers, null, 2)}\n`, 'utf8');
console.log(`Berhasil membuat ${outputFile}`);
console.log(`Total stiker: ${stickers.length} dari ${folders.length} folder coin`);
