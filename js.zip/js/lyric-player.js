/**
 * LYRIC PLAYER MODULE FOR STREAM OVERLAY
 */

// State Management Lirik
let currentLyricsArray = [];
let activeLyricIndex = -1;
let currentSongTitle = "";

// Elemen DOM (Nanti disesuaikan dengan HTML Overlay)
const lyricContainer = document.getElementById('lyric-container');
const lyricTextElement = document.getElementById('lyric-text'); // Untuk 1 baris aktif

/**
 * 1. Fetch Lirik dari Backend Server
 */
async function fetchLyricsForSong(songTitle) {
    if (!songTitle || songTitle === currentSongTitle) return;

    currentSongTitle = songTitle;
    currentLyricsArray = [];
    activeLyricIndex = -1;

    // Reset Tampilan saat loading
    updateLyricUI("🎵 Mencari lirik...");

    try {
        const response = await fetch(`/api/lyrics?title=${encodeURIComponent(songTitle)}`);
        const data = await response.json();

        if (data.success && data.lyrics && data.lyrics.length > 0) {
            currentLyricsArray = data.lyrics;
            console.log(`✅ Lirik berhasil dimuat (${currentLyricsArray.length} baris)`);

            // Render ulang container jika ingin tampilan multi-baris (scrolling)
            renderMultiLineLyrics(currentLyricsArray);
            updateLyricUI("---");
        } else {
            console.log("⚠️ Lirik tidak ditemukan / tidak ter-sync");
            updateLyricUI("♪ Musik Memutar ♪");
        }
    } catch (error) {
        console.error("❌ Gagal mengambil lirik:", error);
        updateLyricUI("♪ Musik Memutar ♪");
    }
}

/**
 * 2. Mencari Baris Lirik yang Aktif Berdasarkan Detik Lagu (currentTime)
 */
function syncLyricWithTime(currentTime) {
    if (!currentLyricsArray || currentLyricsArray.length === 0) return;

    let newIndex = -1;

    // Cari indeks baris lirik terakhir yang waktunya <= currentTime
    for (let i = 0; i < currentLyricsArray.length; i++) {
        if (currentTime >= currentLyricsArray[i].time) {
            newIndex = i;
        } else {
            break;
        }
    }

    // Jika indeks berubah (berpindah ke baris lirik baru)
    if (newIndex !== -1 && newIndex !== activeLyricIndex) {
        activeLyricIndex = newIndex;
        const activeLine = currentLyricsArray[activeLyricIndex];

        // Update UI Lirik Aktif
        highlightActiveLyric(activeLyricIndex, activeLine.text);
    }
}

/**
 * 3. Update UI Teks Lirik (Mode Single Line)
 */
function updateLyricUI(text) {
    if (lyricTextElement) {
        lyricTextElement.innerText = text;
    }
}

/**
 * 4. Highlight & Auto-Scroll (Mode Multi-Line / Teleprompter Style)
 */
function renderMultiLineLyrics(lyrics) {
    if (!lyricContainer) return;

    lyricContainer.innerHTML = ''; // Clear container

    lyrics.forEach((line, index) => {
        const p = document.createElement('p');
        p.id = `lyric-line-${index}`;
        p.className = 'lyric-line';
        p.innerText = line.text;
        lyricContainer.appendChild(p);
    });
}

function highlightActiveLyric(index, text) {
    if (lyricContainer) {
        // Efek animasi transisi teks bergantian
        lyricContainer.style.opacity = '0';

        setTimeout(() => {
            lyricContainer.innerHTML = `<p class="lyric-line active">${text}</p>`;
            lyricContainer.style.opacity = '1';
        }, 150);
    }
}

// =================================================================
// 🔌 INTEGRASI SOCKET.IO DARI SERVER
// =================================================================

// Pastikan variabel 'socket' sudah didefinisikan dari socket.io client di overlay kamu
if (typeof socket !== 'undefined') {

    // A. Mendengar event pergantian lagu / sync queue
    socket.on('update-queue', (data) => {
        if (data && data.currentSong) {
            fetchLyricsForSong(data.currentSong.title);
        } else {
            currentLyricsArray = [];
            currentSongTitle = "";
            updateLyricUI("");
            if (lyricContainer) lyricContainer.innerHTML = '';
        }
    });

    // B. Mendengar event tick detik lagu dari server Music Timer
    let lyricsArray = []; // Menyimpan list lirik { time: 12.3, text: "..." }

    // Socket Listener
    socket.on('music-tick', (data) => {
        if (!data || data.currentTime === undefined) return;

        const currentTime = data.currentTime;
        if (!lyricsArray || lyricsArray.length === 0) return;

        // Cari baris lirik aktif berdasarkan detik lagu saat ini
        let activeIndex = -1;
        for (let i = 0; i < lyricsArray.length; i++) {
            if (currentTime >= lyricsArray[i].time) {
                activeIndex = i;
            } else {
                break;
            }
        }

        if (activeIndex !== -1) {
            highlightActiveLyric(activeIndex, lyricsArray[activeIndex].text);
        }
    });
}