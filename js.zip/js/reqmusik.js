// Database utama kamu yang sinkron berdasarkan key pemanggilan dari HTML
const OverlayDatabase = {
    songrequest: [
        { name: 'Lo-Fi Anime Aesthetic', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/kotak.html', testFunc: 'testMusic' },
        { name: 'Lo-Fi Anime Aesthetic', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/anim.html', testFunc: 'testMusic' },
        { name: 'Black Silver Turntable', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/silver.html', testFunc: 'testMusic' },
        { name: 'Turntable Vinyl', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/turn.html', testFunc: 'testMusic' },
        { name: 'Player Reimagined', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/player.html', testFunc: 'testMusic' },
        { name: 'Sage Music', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/turtable.html', testFunc: 'testMusic' },
        { name: 'Tokyo Music', desc: 'Menampilkan Music Overlay dengan gaya lampu neon khas Tokyo', url: '/themes/musik/play/tokyo.html', testFunc: 'testMusic' },
        { name: 'Cascading Deck', desc: 'Menampilkan Music Overlay model kapsul modern', url: '/themes/musik/play/deck.html', testFunc: 'testMusic' },
        { name: 'Cover Flow 3D', desc: 'Menampilkan Music Overlay model kapsul modern', url: '/themes/musik/play/3d.html', testFunc: 'testMusic' },
        { name: 'Pemutar Vinyl', desc: 'Menampilkan Music Overlay model kapsul modern', url: '/themes/musik/play/vinyl.html', testFunc: 'testMusic' },
        { name: 'Olive Capsule Music', desc: 'Menampilkan Music Overlay unik ala robekan kertas catatan', url: '/themes/musik/play/papernote.html', testFunc: 'testMusic' },
        { name: 'Modern Portrait Music', desc: 'Menampilkan Music Overlay model kapsul modern', url: '/themes/musik/play/capsul.html', testFunc: 'testMusic' },
        { name: 'Glassmorphic', desc: 'Menampilkan Music Overlay efek kaca transparan ala anime', url: '/themes/musik/play/glassmorphic-anime.html', testFunc: 'testMusic' },
        { name: 'Minimalist Dark', desc: 'Menampilkan Music Overlay tema gelap simpel dan elegan', url: '/themes/musik/play/minimalist-dark.html', testFunc: 'testMusic' }
    ],
    queuelist: [
        { name: 'Golden Theme', desc: 'Menampilkan daftar antrean vertikal minimalis di sisi layar', url: '/themes/musik/list/style3.html', testFunc: 'testQueue' },
        { name: 'Frosted Glass', desc: 'Menampilkan daftar antrean vertikal minimalis di sisi layar', url: '/themes/musik/list/style2.html', testFunc: 'testQueue' },
        { name: 'Music List Style', desc: 'Menampilkan daftar antrean vertikal minimalis di sisi layar', url: '/themes/musik/list/style1.html', testFunc: 'testQueue' },
        { name: 'Compact Sidebar List', desc: 'Menampilkan daftar antrean vertikal minimalis di sisi layar', url: '/themes/musik/list/compact-sidebar-list.html', testFunc: 'testQueue' },
        { name: 'Paper Slider Style', desc: 'Menampilkan antrean bergerak ke samping dengan gaya kertas unik', url: '/themes/musik/list/paper.html', testFunc: 'testQueue' }

    ],
    formatlist: [
        { name: '3D Cartoon Music', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/cartoon.html', testFunc: 'testFormat' },
        { name: 'Pixel Arcade Music', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/arcade.html', testFunc: 'testFormat' },
        { name: 'Simple Info Ticker', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/barinfo.html', testFunc: 'testFormat' },
        { name: 'Large Aesthetic Scrapbook', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/darkkuning.html', testFunc: 'testFormat' },
        { name: 'Flicker Typography', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/simple.html', testFunc: 'testFormat' },
        { name: 'Bold Gradient Typography', desc: 'Menampilkan Format Request Lagu', url: '/themes/musik/petunjuk/petunjuk.html', testFunc: 'testFormat' },
        { name: 'Bold 3D Style', desc: 'Menampilkan Format Wajib Gift Rose', url: '/themes/musik/petunjuk/playgift.html', testFunc: 'testFormat' },
    ],
    rejectedlist: [
        { name: 'Request (Mode Gift)', desc: 'notifikasi aktif tanpa mengirim gift.', url: '/themes/musik/warning/overlay-request-warning.html', testFunc: 'testMode' },
    ],
    lyrics: [
        { name: 'Rising Script Lyrics', desc: 'Menampilkan overlay lirik realtime dengan efek kaca dark glassmorphic.', url: '/themes/musik/lirik/style5.html', testFunc: 'testLyrics' },
        { name: 'Grain Style', desc: 'Menampilkan lirik melayang 1 baris ala subtitle video minimalis.', url: '/themes/musik/lirik/grain.html', testFunc: 'testLyrics' },
        { name: 'Cinematic Lyrics Overlay', desc: 'Menampilkan overlay lirik realtime dengan efek kaca dark glassmorphic.', url: '/themes/musik/lirik/style1.html', testFunc: 'testLyrics' },
        { name: 'Cinematic Grup', desc: 'Menampilkan overlay lirik realtime dengan efek kaca dark glassmorphic.', url: '/themes/musik/lirik/style2.html', testFunc: 'testLyrics' }
    ],
    songrating: [
        { name: 'Song Rating Overlay', desc: 'Menampilkan rating penonton setelah lagu selesai diputar.', url: '/themes/musik/rate/song-rating-overlay.html', testFunc: 'testMusic' }
    ],
    fasttrack: [
        {
            name: 'Battle Fasttrack — Tahta Berganti',
            desc: 'Menampilkan animasi saat pemimpin coin berubah.',
            url: '/themes/musik/fasttrack/fasttrack-leader-overlay.html',
            testFunc: 'testMusic',
            previewUrl: '/themes/musik/fasttrack/fasttrack-leader-overlay.html?demo=1'
        }
    ]

};

// Config metadata khusus untuk UI teks modalnya saja
const musicModalConfig = {
    songrequest: { modalTitle: 'Pilihan Tema Musik', modalSubTitle: 'Song Request Style', cardIcon: 'fa-music' },
    queuelist: { modalTitle: 'Pilihan Tema Antrean', modalSubTitle: 'Queue Board Style', cardIcon: 'fa-list-ol' },
    formatlist: { modalTitle: 'Pilihan Tema Format List', modalSubTitle: 'Format Text Request', cardIcon: 'fa-circle-info' },
    rejectedlist: { modalTitle: 'Pilihan Tema Mode Gift', modalSubTitle: 'Mode Gift Request', cardIcon: 'fa-circle-xmark' },
    lyrics: { modalTitle: 'Pilihan Tema Lirik', modalSubTitle: 'Lyrics Display Style', cardIcon: 'fa-align-left' },
    songrating: { modalTitle: 'Pilihan Overlay Rating Lagu', modalSubTitle: 'Song Rating Overlay', cardIcon: 'fa-star' },
    fasttrack: { modalTitle: 'Pilihan Tema Battle Fasttrack', modalSubTitle: 'Fasttrack Leader Overlay', cardIcon: 'fa-bolt' }

};

let selectedUrl = '';

/**
 * FUNGSI BUKA MODAL YANG MENARIK DATA BERDASARKAN PARAMETER DI HTML CARD
 */
function openMusicModal(categoryKey) {
    const styles = OverlayDatabase[categoryKey];
    const config = musicModalConfig[categoryKey];

    if (!styles || !config) return;

    // Pasang Text & Icon dinamis di modal
    document.getElementById('modalTitle').innerText = config.modalTitle;
    document.getElementById('modalSubTitle').innerText = config.modalSubTitle;
    document.getElementById('modalIcon').className = `fa-solid ${config.cardIcon}`;

    // Tarik list sub-item gaya ke panel kiri modal
    const listContainer = document.getElementById('styleListContainer');
    listContainer.innerHTML = '';

    styles.forEach((style, index) => {
        const optionDiv = document.createElement('div');
        optionDiv.className = `style-option ${index === 0 ? 'active' : ''}`;
        optionDiv.innerHTML = `
            <h4>${style.name}</h4>
            <p>${style.desc}</p>
        `;

        // Load default preview di index pertama
        if (index === 0) {
            updateLivePreview(style.previewUrl || style.url, style.url);

        }

        // Ubah preview & class active jika item diklik
        optionDiv.onclick = function () {
            document.querySelectorAll('.style-option').forEach(opt => opt.classList.remove('active'));
            this.classList.add('active');

            // Trigger fungsi test asli bawaan template kamu jika ada
            if (typeof window[style.testFunc] === "function") {
                window[style.testFunc]();
            }

            updateLivePreview(style.previewUrl || style.url, style.url);

        };

        listContainer.appendChild(optionDiv);
    });

    document.getElementById('dynamicMusicModal').style.display = 'flex';
}

function updateLivePreview(url, copyUrl = url) {
    selectedUrl = copyUrl;
    const previewContent = document.getElementById('livePreviewContent');

    // 1. Buat elemen iframe secara dinamis
    const iframe = document.createElement('iframe');
    iframe.src = url;
    iframe.className = 'scaled-iframe';
    iframe.style.width = '100%';
    iframe.style.height = '100%';
    iframe.style.border = 'none';

    // 2. JAMPI-JAMPI PAMUNGKAS MUTLAK: Kita pasang sandbox TANPA 'allow-same-origin' jika kategori 'songrequest'
    // Ini memaksa iframe dianggap sebagai lintas domain asing, sehingga browser otomatis memblokir suara/fitur audionya!
    if (url.includes('/play/') || url.includes('/lirik/')) {
        iframe.setAttribute('sandbox', 'allow-scripts');
    } else {
        // Untuk daftar antrean dll, biarkan normal
        iframe.setAttribute('sandbox', 'allow-scripts allow-same-origin');
    }

    // 3. Masukkan ke dalam container preview kamu
    previewContent.innerHTML = '<div class="iframe-scaler-wrapper"></div>';
    previewContent.querySelector('.iframe-scaler-wrapper').appendChild(iframe);
}

function closeMusicModal() {
    document.getElementById('dynamicMusicModal').style.display = 'none';
}

/**
 * LOGIKA CUSTOM ALERT TOAST (PENGGANTI ALERT BROWSER)
 */
function showCustomToast(message) {
    const toast = document.getElementById('customToast');
    const toastMsg = document.getElementById('toastMessage');

    toastMsg.innerText = message;
    toast.classList.add('show'); // Munculkan toast meluncur ke bawah

    // Otomatis sembunyikan kembali setelah 3 detik
    setTimeout(() => {
        toast.classList.remove('show');
    }, 3000);
}

function applyMusicSettings() {
    if (!selectedUrl) {
        showCustomToast("Gagal: Belum ada tema yang terpilih!");
        return;
    }

    // Gabungkan domain + path file overlay
    const fullOverlayUrl = window.location.origin + selectedUrl;

    // Eksekusi salin ke clipboard sistem
    navigator.clipboard.writeText(fullOverlayUrl)
        .then(() => {
            // Munculkan toast alert kustom di dalam modal
            showCustomToast(`Sukses menyalin link ke clipboard!`);

            // ❌ KODE `closeMusicModal();` DIHAPUS BIAR MODAL TETAP TERBUKA
        })
        .catch(err => {
            console.error('Gagal menyalin link: ', err);
            showCustomToast("Gagal menyalin link otomatis.");
        });
}

// Tutup modal jika luar container diklik
window.onclick = function (event) {
    const modal = document.getElementById('dynamicMusicModal');
    if (event.target === modal) {
        closeMusicModal();
    }
};

