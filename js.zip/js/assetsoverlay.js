// 1. Data tema yang dipetakan sesuai kebutuhan menu aplikasi kamu brow
const rvOverlayDatabase = {
    chatoverlay: [
        { name: 'Emerald Dynamic Typography', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/emerald.html', testFunc: 'showChat' },
        { name: 'Anime VTuber Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/vtuber.html', testFunc: 'showChat' },
        { name: 'Gold Quotation Glass', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/gold.html', testFunc: 'showChat' },
        { name: 'Real Time Analytics', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/analistik.html', testFunc: 'showChat' },
        { name: 'Profile Card Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/style01.html', testFunc: 'showChat' },
        { name: 'Travel Card Design', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/travel.html', testFunc: 'showChat' },
        { name: 'Dark Capsul Design', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/darkcapsulos.html', testFunc: 'showChat' },
        { name: 'Widi Tomz OS', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/widi/widi.html', testFunc: 'showChat' },
        { name: 'Aesthetic Cat Profile Floating', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/cat.html', testFunc: 'showChat' },
        { name: 'Aesthetic Soft Floating', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/floating.html', testFunc: 'showChat' },
        { name: 'TikTok Custom Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/tiktok.html', testFunc: 'showChat' },
        { name: 'Custom Badge', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/badge.html', testFunc: 'showChat' },
        { name: 'AI Robot Speech', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/robot.html', testFunc: 'showChat' },
        { name: 'Double Layer Capsule', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/layer.html', testFunc: 'showChat' },
        { name: 'Pill Gradient Input Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/fill.html', testFunc: 'showChat' },
        { name: 'Random Neon Glassmorphism', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/randomneon.html', testFunc: 'showChat' },
        { name: 'Tactical Military HUD', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/tactical.html', testFunc: 'showChat' },
        { name: 'Minimalist Avatar & Text', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/avatar.html', testFunc: 'showChat' },
        { name: 'Comic Pop Bubble', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/comic.html', testFunc: 'showChat' },
        { name: 'Random Split Capsule', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/random.html', testFunc: 'showChat' },
        { name: 'Avatar Text Masking', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/avatartext.html', testFunc: 'showChat' },
        { name: 'Typographic Warrior Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/typo.html', testFunc: 'showChat' },
        { name: 'Giant Right-Aligned', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/giantwater.html', testFunc: 'showChat' },
        { name: 'Waterdrop Custom Font & Color', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/waterdropcolor.html', testFunc: 'showChat' },
        { name: 'Waterdrop Clean Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/waterdrop.html', testFunc: 'showChat' },
        { name: 'Instagram Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/instagram.html', testFunc: 'showChat' },
        { name: 'macOS Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/macos.html', testFunc: 'showChat' },
        { name: 'Box Style Desc', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/boxdesc.html', testFunc: 'showChat' },
        { name: 'IG Story Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/ig.html', testFunc: 'showChat' },
        { name: 'Roblox Game Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/roblox.html', testFunc: 'showChat' },
        { name: 'Kawaiikorean', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/kawaikorean.html', testFunc: 'showChat' },
        { name: 'Cartoon White', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/carton.html', testFunc: 'showChat' },
        { name: 'Glassmorphism Premium', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/glass.html', testFunc: 'showChat' },
        { name: 'Foto Booth', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/fotoboot.html', testFunc: 'showChat' },
        { name: 'Dark Capsul Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/darkcapsul.html', testFunc: 'showChat' },
        { name: 'White Capsul Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/capsulwater.html', testFunc: 'showChat' },
        { name: 'Capsul Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/capsul.html', testFunc: 'showChat' },
        { name: 'iOS Dark', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/iosdark.html', testFunc: 'showChat' },
        { name: 'Dynamic Island Edition', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/dynamicisland.html', testFunc: 'showChat' },
        { name: 'Anime Style', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/anime.html', testFunc: 'showChat' },
        { name: 'Avatar Box', desc: 'Menampilkan Chat Overlay', url: '/themes/chatbox/avatarbox.html', testFunc: 'showChat' }
    ],
    dockchat: [
        { name: 'Horizontal', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/horizontal.html', testFunc: 'showChat' },
        { name: 'Vertical', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/vertical.html', testFunc: 'showChat' },

        { name: 'Aesthetic Winding Path', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/winding.html', testFunc: 'showChat' },
        { name: '3D Tactile Flow', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/3dscroll.html', testFunc: 'showChat' },
        { name: 'Radial Arc Wheel', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/arc.html', testFunc: 'showChat' },
        { name: 'Activity Timeline', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/truksi01.html', testFunc: 'showChat' },
        { name: 'Timeline Schedule', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/truksi.html', testFunc: 'showChat' },
        { name: '3D Phone Pop-Out', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/phone.html', testFunc: 'showChat' },
        { name: 'Clean Pop-In Style', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/clean.html', testFunc: 'showChat' },
        { name: 'Physics Fall & Stacked', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/fall.html', testFunc: 'showChat' },
        { name: 'Stacked Neon Glassmorphism', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/stacked.html', testFunc: 'showChat' },
        { name: 'Neon Pop ZigZag', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/neon.html', testFunc: 'showChat' },
        { name: 'ZigZag Conversation', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/zigzag.html', testFunc: 'showChat' },
        { name: 'Random Colorful Flat', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/random.html', testFunc: 'showChat' },
        { name: 'Bubble Chat IG', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/bubbleig.html', testFunc: 'showChat' },
        { name: 'Live Chat Buble', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/livechatbubble.html', testFunc: 'showChat' },
        { name: 'Glow Chat', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/glowchat.html', testFunc: 'showChat' },
        { name: 'Retrow Style', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/retro.html', testFunc: 'showChat' },
        { name: 'Telegram Style', desc: 'Menampilkan Chat Overlay', url: '/themes/dockchat/telegram.html', testFunc: 'showChat' }
    ],
    musicoverlay: [
        { name: 'Vinyl Music Overlay', desc: 'Menampilkan judul, artis, artwork, dan status musik dari Windows.', url: '/themes/ovmusik/style1.html', testFunc: '' },
        { name: 'Turntable Music', desc: 'Menampilkan judul, artis, artwork, dan status musik dari Windows.', url: '/themes/ovmusik/style2.html', testFunc: '' },
        { name: 'Layered Vinyl Music', desc: 'Menampilkan judul, artis, artwork, dan status musik dari Windows.', url: '/themes/ovmusik/style3.html', testFunc: '' },
        { name: 'Realistic 3D Vinyl Music', desc: 'Menampilkan judul, artis, artwork, dan status musik dari Windows.', url: '/themes/ovmusik/style4.html', testFunc: '' }
    ],
    milestone: [
        { name: 'Milestone 3D Stack Rotator', desc: 'Menampilkan target goal gift dengan progress bar.', url: '/themes/milestone/bar2.html', testFunc: 'showMilestone' },
        { name: 'Multi-Milestone', desc: 'Menampilkan target goal gift dengan progress bar.', url: '/themes/milestone/bar1.html', testFunc: 'showMilestone' },
        { name: 'Glassmorphism Milestone Bar', desc: 'Menampilkan target goal gift dengan progress bar.', url: '/themes/milestone/bar.html', testFunc: 'showMilestone' }
    ],
    dockgift: [
        { name: 'Vertical Capsule List', desc: 'Menampilkan semua daftar benefit gift secara vertikal di layar.', url: '/themes/giftform/vertical-list.html', testFunc: 'showGiftList' },
        { name: 'Horizontal Minimalist', desc: 'Menampilkan daftar benefit gift berjejer ke samping di bawah layar.', url: '/themes/giftform/horizontal-list.html', testFunc: 'showGiftHorizontal' }
    ],
    weather: [
        { name: '3D Card Style', desc: 'Metric standard UI text', url: '/themes/cuaca/3d.html', testFunc: 'showWeather' },
        { name: 'Weather Overlay Widget', desc: 'Metric standard UI text', url: '/themes/cuaca/wather.html', testFunc: 'showWeather' },
        { name: 'Metric Weather', desc: 'Metric standard UI text', url: '/themes/cuaca/cuacawidget.html', testFunc: 'showWeather' },
        { name: 'Weather Insights', desc: 'Detailed tracking cards', url: '/themes/cuaca/infolocation.html', testFunc: 'showWeather' }
    ],
    usergift: [
        { name: 'Vertical Slide', desc: 'Special Ivent Gift', url: '/themes/usergiftoverlay/temadark.html', testFunc: 'showGift' },
    ],
    social: [
        { name: 'Social Media', desc: 'Menampilkan Social Media Overlay', url: '/themes/social/social.html', testFunc: 'showSocial' }
    ],
    network: [
        { name: 'Glassmorphic Gradient Widget', desc: 'Menampilkan data kecepatan internet', url: '/themes/utils/win.html', testFunc: 'initNetwork' },
        { name: 'Network Monitor Search', desc: 'Menampilkan data kecepatan internet', url: '/themes/utils/engine.html', testFunc: 'initNetwork' },
        { name: 'Networking Realtime', desc: 'Menampilkan data kecepatan internet', url: '/themes/utils/network.html', testFunc: 'initNetwork' }
    ],
    hardware: [
        { name: 'Retro Pop-up Stack Style', desc: 'Menampilkan spek PC secara realtime', url: '/themes/hardware/retro.html', testFunc: '' },
        { name: 'Smart Dashboard Style', desc: 'Menampilkan spek PC secara realtime', url: '/themes/hardware/smart.html', testFunc: '' },
        { name: 'Hardware Widget', desc: 'Menampilkan spek PC secara realtime', url: '/themes/hardware/hardware.html', testFunc: '' },
        { name: 'Glassmorphism', desc: 'Menampilkan spek PC secara realtime', url: '/themes/hardware/glass.html', testFunc: '' },
        { name: 'Minimal', desc: 'Menampilkan spek PC secara realtime', url: '/themes/hardware/minimal.html', testFunc: '' }
    ],
    topgift: [
        { name: 'Dark Glassmorphism', desc: 'Menampilkan Top Gift', url: '/themes/topgift/darkglass.html', testFunc: 'updateLeaderboard' },
        { name: 'Visual Style Off-White Capsule', desc: 'Menampilkan Top Gift', url: '/themes/topgift/capsule.html', testFunc: 'updateLeaderboard' },
        { name: 'Stacked Random UI Bubbles', desc: 'Menampilkan Top Gift', url: '/themes/topgift/randomstyle.html', testFunc: 'updateLeaderboard' },
        { name: 'Bubble Pop Minimalist Theme', desc: 'Menampilkan Top Gift', url: '/themes/topgift/bubble.html', testFunc: 'updateLeaderboard' },
        { name: 'Simple', desc: 'Menampilkan Top Gift', url: '/themes/topgift/simple.html', testFunc: 'updateLeaderboard' },
        { name: 'Dark Natural', desc: 'Menampilkan Top Gift', url: '/themes/topgift/topgift.html', testFunc: 'updateLeaderboard' },
        { name: 'Compact Mode', desc: 'Menampilkan Top Gift', url: '/themes/topgift/topgift1.html', testFunc: 'updateLeaderboard' }
    ],
    toplike: [
        { name: 'Plus Origin Burst', desc: 'Menampilkan Top Like', url: '/themes/toplike/style14.html', testFunc: 'renderLeaderboard' },
        { name: 'Card Stack Focus', desc: 'Menampilkan Top Like', url: '/themes/toplike/style13.html', testFunc: 'renderLeaderboard' },
        { name: 'Perfect Center', desc: 'Menampilkan Top Like', url: '/themes/toplike/style12.html', testFunc: 'renderLeaderboard' },
        { name: 'Dynamic Burst Capsule', desc: 'Menampilkan Top Like', url: '/themes/toplike/style11.html', testFunc: 'renderLeaderboard' },
        { name: 'Asymmetric Modern UI', desc: 'Menampilkan Top Like', url: '/themes/toplike/style10.html', testFunc: 'renderLeaderboard' },
        { name: 'Messy Stacked UI', desc: 'Menampilkan Top Like', url: '/themes/toplike/style9.html', testFunc: 'renderLeaderboard' },
        { name: 'Pure Minimalist', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike8.html', testFunc: 'renderLeaderboard' },
        { name: 'Dark Black', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike7.html', testFunc: 'renderLeaderboard' },
        { name: 'Premium E-sports', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike6.html', testFunc: 'renderLeaderboard' },
        { name: 'Base Styling', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike1.html', testFunc: 'renderLeaderboard' },
        { name: 'Capsul Style', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike2.html', testFunc: 'renderLeaderboard' },
        { name: 'Box Gradient', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike3.html', testFunc: 'renderLeaderboard' },
        { name: 'Simple Dark', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike4.html', testFunc: 'renderLeaderboard' },
        { name: 'Drak Black', desc: 'Menampilkan Top Like', url: '/themes/toplike/toplike5.html', testFunc: 'renderLeaderboard' }
    ],
    join: [
        { name: 'Fruit Ninja Slash Style', desc: 'Menampilkan Alert Join', url: '/themes/join/join14.html', testFunc: 'showJoin' },
        { name: 'iOS Stacking Notification', desc: 'Menampilkan Alert Join', url: '/themes/join/join13.html', testFunc: 'showJoin' },
        { name: 'Hyperdrive Glitch Shockwave', desc: 'Menampilkan Alert Join', url: '/themes/join/join12.html', testFunc: 'showJoin' },
        { name: 'Tech Mechanical Unfold', desc: 'Menampilkan Alert Join', url: '/themes/join/join11.html', testFunc: 'showJoin' },
        { name: 'Anime Cyber Jelly Alert', desc: 'Menampilkan Alert Join', url: '/themes/join/join10.html', testFunc: 'showJoin' },
        { name: 'Interactive Click & Burst Alert', desc: 'Menampilkan Alert Join', url: '/themes/join/join9.html', testFunc: 'showJoin' },
        { name: 'Cyberpunk Neon', desc: 'Menampilkan Alert Join', url: '/themes/join/join8.html', testFunc: 'showJoin' },
        { name: 'Clean Minimalist Floating', desc: 'Menampilkan Alert Join', url: '/themes/join/join7.html', testFunc: 'showJoin' },
        { name: 'Capsule Floating', desc: 'Menampilkan Alert Join', url: '/themes/join/join6.html', testFunc: 'showJoin' },
        { name: 'Mode rocketIn', desc: 'Menampilkan Alert Join', url: '/themes/join/join1.html', testFunc: 'showJoin' },
        { name: 'Babol Luttu', desc: 'Menampilkan Alert Join', url: '/themes/join/join3.html', testFunc: 'showJoin' },
        { name: 'Capsul Style', desc: 'Menampilkan Alert Join', url: '/themes/join/join4.html', testFunc: 'showJoin' },
        { name: 'Noise Babol Luttu', desc: 'Menampilkan Alert Join', url: '/themes/join/join5.html', testFunc: 'showJoin' }
    ],
    giftalert: [
        { name: 'Roblox Blocky Style', desc: 'Menampilkan Alert Gift', url: '/themes/gift/roblok.html', testFunc: 'showGift' },
        { name: 'Scrapbook Creative Block', desc: 'Menampilkan Alert Gift', url: '/themes/gift/blok.html', testFunc: 'showGift' },
        { name: 'Modern Stack Gift Alert', desc: 'Menampilkan Alert Gift', url: '/themes/gift/trend.html', testFunc: 'showGift' },
        { name: 'Gift Widi Overlay', desc: 'Menampilkan Alert Gift', url: '/themes/gift/widi/widistyle.html', testFunc: 'showGift' },
        { name: 'Wednesday Sequential Stagger', desc: 'Menampilkan Alert Gift', url: '/themes/gift/dadu.html', testFunc: 'showGift' },
        { name: 'Rocket Launch', desc: 'Menampilkan Alert Gift', url: '/themes/gift/roket.html', testFunc: 'showGift' },
        { name: 'Blocks Style', desc: 'Menampilkan Alert Gift', url: '/themes/gift/giftgokil.html', testFunc: 'showGift' },
        { name: 'Stiker Gif', desc: 'Menampilkan Alert Gift', url: '/themes/gift/gift.html', testFunc: 'showGift' },
        { name: 'Festive Slash Fireworks', desc: 'Menampilkan Alert Gift', url: '/themes/gift/giftbaru.html', testFunc: 'showGift' }
    ],
    duration: [
        { name: 'Timer Clean', desc: 'Menampilkan Durasi Overlay', url: '/themes/duration/durasi1.html', testFunc: 'showDuration' },
        { name: 'Cyber Timer', desc: 'Menampilkan Durasi Overlay', url: '/themes/duration/durasi2.html', testFunc: 'showDuration' },
        { name: 'Clean Minimalis', desc: 'Menampilkan Durasi Overlay', url: '/themes/duration/durasi3.html', testFunc: 'showDuration' }
    ],
    viewerstats: [
        { name: 'Capsule Switcher', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style16.html', testFunc: 'showView' },
        { name: 'Vertical Navigation Card', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style15.html', testFunc: 'showView' },
        { name: 'Dynamic Island', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style14.html', testFunc: 'showView' },
        { name: 'Orange iOS Widget', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style13.html', testFunc: 'showView' },
        { name: 'iOS Widget Glitch with Clock', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style12.html', testFunc: 'showView' },
        { name: 'TikTok Live Stats', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/style11.html', testFunc: 'showView' },
        { name: 'Squircle Glitz', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats10.html', testFunc: 'showView' },
        { name: 'Dark Natural', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats7.html', testFunc: 'showView' },
        { name: 'Glassmorphism', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats6.html', testFunc: 'showView' },
        { name: 'Deep Night & Neon', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats1.html', testFunc: 'showView' },
        { name: 'Neon Potret', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats2.html', testFunc: 'showView' },
        { name: 'Mode Tiktok', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats3.html', testFunc: 'showView' },
        { name: 'Capsul Dark', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats4.html', testFunc: 'showView' },
        { name: 'Dark Simple', desc: 'Menampilkan Viewer Overlay', url: '/themes/view/stats5.html', testFunc: 'showView' }
    ],
    followergoal: [
        { name: 'Style 1', desc: 'Menampilkan Goals Followers Overlay', url: '/themes/goal/follower1.html', testFunc: 'showGoal' },
        { name: 'Style 2', desc: 'Menampilkan Goals Followers Overlay', url: '/themes/goal/follower2.html', testFunc: 'showGoal' },
        { name: 'Style 3', desc: 'Menampilkan Goals Followers Overlay', url: '/themes/goal/follower3.html', testFunc: 'showGoal' },
        { name: 'Style 4', desc: 'Menampilkan Goals Followers Overlay', url: '/themes/goal/follower4.html', testFunc: 'showGoal' },
        { name: 'Style 5', desc: 'Menampilkan Goals Followers Overlay', url: '/themes/goal/follower5.html', testFunc: 'showGoal' }
    ],
    combogift: [
        { name: 'Neon Combo Overlay', desc: 'Menampilkan COmbo Gift Overlay', url: '/themes/combogift/combogift.html', testFunc: 'showCombo' },
    ],
    share: [
        { name: 'Keycaps Pop-Art', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share12.html', testFunc: 'showShare' },
        { name: 'TOA/Megaphone', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share11.html', testFunc: 'showShare' },
        { name: 'Sequential bounce', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share10.html', testFunc: 'showShare' },
        { name: 'Staggered bounce impact', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share9.html', testFunc: 'showShare' },
        { name: 'Yellow Pill Alert', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share8.html', testFunc: 'showShare' },
        { name: 'Apple Wallet UI Style', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share7.html', testFunc: 'showShare' },
        { name: 'Neumorphic', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share6.html', testFunc: 'showShare' },
        { name: 'Label Style', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share.html', testFunc: 'showShare' },
        { name: 'Capsul Black', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share2.html', testFunc: 'showShare' },
        { name: 'SImple Red', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share3.html', testFunc: 'showShare' },
        { name: 'Avatar Glow', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share4.html', testFunc: 'showShare' },
        { name: 'Avtar Animation', desc: 'Menampilkan Share Live Overlay', url: '/themes/share/share5.html', testFunc: 'showShare' }
    ],
    follower: [
        { name: 'Cyber-Acid Pop', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow7.html', testFunc: 'showFollow' },
        { name: 'Emerald-Lime', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow6.html', testFunc: 'showFollow' },
        { name: 'Elegant Warm-Dark', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow5.html', testFunc: 'showFollow' },
        { name: 'White Silver Glow', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow1.html', testFunc: 'showFollow' },
        { name: 'Industrial Stamp', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow2.html', testFunc: 'showFollow' },
        { name: 'Crumpled Paper', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow3.html', testFunc: 'showFollow' },
        { name: 'Explosion Burst', desc: 'Menampilkan Follower Overlay', url: '/themes/follow/follow4.html', testFunc: 'showFollow' }
    ],
    clock: [
        { name: 'Radial Focus Clock', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style9.html', testFunc: 'showClock' },
        { name: 'Half Radial', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style8.html', testFunc: 'showClock' },
        { name: 'Rotating Dial Clock', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style7.html', testFunc: 'showClock' },
        { name: 'Widget Jam & Tanggal Premium', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style6.html', testFunc: 'showClock' },
        { name: 'Simple White', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style1.html', testFunc: 'showClock' },
        { name: 'Style Capsul', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style2.html', testFunc: 'showClock' },
        { name: 'MacOS Code', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style3.html', testFunc: 'showClock' },
        { name: 'Musik Style', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style4.html', testFunc: 'showClock' },
        { name: 'Green Dark', desc: 'Menampilkan Jam Overlay', url: '/themes/clock/style5.html', testFunc: 'showClock' }
    ],
    brandtext: [
        { name: 'ROOW Tech Overlay', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/style3.html', testFunc: 'showBrand' },
        { name: 'Staggered Overlay Banner', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/style2.html', testFunc: 'showBrand' },
        { name: 'Cyber-Acid Poster', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/style1.html', testFunc: 'showBrand' },
        { name: 'Minimalist Smooth Slide', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/smooth.html', testFunc: 'showBrand' },
        { name: 'Minimalist Scattered', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/minimalis.html', testFunc: 'showBrand' },
        { name: 'Random Scattered', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/random.html', testFunc: 'showBrand' },
        { name: 'Rotator Brand Text', desc: 'Menampilkan Rotator Brand Text Overlay', url: '/themes/brand/rotator.html', testFunc: 'showBrand' }
    ],
    battlesquad: [
        { name: 'Battle 1 Vs 2', desc: 'Menampilkan Overlay Battle', url: '/themes/games/battle.html', testFunc: 'showBattle' }
    ],
    tebakkata: [
        { name: 'Tebak Kata Game', desc: 'Menampilkan Overlay Tebak Kata', url: '/themes/games/tebak.html', testFunc: 'showTebak' }
    ],
    monsterraid: [
        { name: 'Monster Raid', desc: 'Menampilkan Overlay Monster', url: '/themes/games/monster.html', testFunc: 'showMonster' }
    ]
    
};

//Data dummy chat overlay
const chatMessagesDummy = [
    "Halo bang, salam kenal! 👋",
    "Gokil overlay-nya jernih banget masbro 🔥",
    "Keren nih temanya, minimalis abis!",
    "Request lagu dong bang nanti 🎵",
    "Gas terus streamingnya, sukses selalu! 🚀"
];

// Data dummy simulasi
const rvDefaultTestData = {
    nickname: "WebDev Tester",
    user: "webdev_tester",
    profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png"
};

// Data dummy simulasi khusus untuk alert join livestream
const rvJoinTestData = {
    nickname: "Sultan_Join",
    uniqueId: "sultan_parepare",
    profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png"
};

// Data dummy khusus untuk simulasi peringkat Top Gift
const rvTopGiftTestData = [
    { nickname: "Sultan Parepare", total: 1500, profilePic: "https://www.w3schools.com/howto/img_avatar.png" },
    { nickname: "WebDev Tester", total: 850, profilePic: "https://www.w3schools.com/howto/img_avatar2.png" },
    { nickname: "Pejuang Koin", total: 420, profilePic: "https://www.w3schools.com/w3images/avatar6.png" }
];

// Data dummy simulasi untuk peringkat Top Like
const rvTopLikeTestData = [
    {
        username: "Sultan Jempol", nickname: "Sultan Jempol",
        count: 25000, likes: 25000,
        pfp: "https://www.w3schools.com/howto/img_avatar.png", profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png"
    },
    {
        username: "Tapper Pro", nickname: "Tapper Pro",
        count: 18200, likes: 18200,
        pfp: "https://www.w3schools.com/howto/img_avatar2.png", profilePictureUrl: "https://www.w3schools.com/howto/img_avatar2.png"
    },
    {
        username: "Zian Gamer", nickname: "Zian Gamer",
        count: 9500, likes: 9500,
        pfp: "https://www.w3schools.com/w3images/avatar6.png", profilePictureUrl: "https://www.w3schools.com/w3images/avatar6.png"
    },
    {
        username: "Viewer Setia", nickname: "Viewer Setia",
        count: 4200, likes: 4200,
        pfp: "https://www.w3schools.com/howto/img_avatar.png",
        profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png"
    }
];

let dummyChatInterval = null;
let currentSelectedThemeUrl = "";
let currentOldSelectId = "";
let currentModalKey = "";
let cachedHardwareSpecs = null;
let modalBrandTextsArray = [];

let ipcRenderer;
try {
    ipcRenderer = require('electron').ipcRenderer;
} catch (e) {
    console.log("Membuka lewat browser standar (Non-Electron environment)");
}

// 2. Fungsi Membuka Modal Pop-up Kustomisasi (OPTIMIZED: NO MORE DELAY)
function openOverlayModal(key, title, oldSelectId) {
    currentOldSelectId = oldSelectId;
    currentModalKey = key;
    currentSelectedThemeUrl = "";

    // 1. Langsung tampilkan modal secara instan
    const modalEl = document.getElementById('rv-overlay-modal');
    modalEl.style.display = 'flex';
    document.getElementById('modal-overlay-title').innerText = title;

    // Tambahkan style pengaman CSS via JS pada kontainer utama modal agar layout tidak hancur/terpotong
    const modalContent = modalEl.querySelector('.rv-modal-content') || modalEl.firstElementChild;
    if (modalContent) {
        modalContent.style.maxHeight = '90vh';
        modalContent.style.overflow = 'hidden';
        modalContent.style.display = 'flex';
        modalContent.style.flexDirection = 'row'; // Sidebar kiri, Preview kanan
    }

    // 2. Ambil data tema secara lokal dulu agar tidak freeze
    const themes = rvOverlayDatabase[key] || [];
    const containerList = document.getElementById('rv-theme-list-vertical');
    containerList.innerHTML = "";

    // Beri scroll area pada sidebar list tema biar tidak jebol ke bawah
    if (containerList) {
        containerList.style.maxHeight = 'calc(90vh - 120px)';
        containerList.style.overflowY = 'auto';
        containerList.style.paddingRight = '5px';
    }

    // 3. Inject kontrol bawaan aplikasi
    injectSpecialControls(key, containerList);

    // 4. RENDER LIST TEMA SECARA INSTAN
    if (themes.length > 0) {
        currentSelectedThemeUrl = themes[0].url;

        themes.forEach((theme, index) => {
            const cardOpt = document.createElement('div');
            cardOpt.className = `theme-card-option ${index === 0 ? 'active' : ''}`;
            cardOpt.innerHTML = `
                <h5>${theme.name}</h5>
                <span>${theme.desc}</span>
            `;

            cardOpt.onclick = function () {
                document.querySelectorAll('.theme-card-option').forEach(c => c.classList.remove('active'));
                cardOpt.classList.add('active');

                setTimeout(() => {
                    triggerIframePreviewWithTest(theme);
                }, 0);

                currentSelectedThemeUrl = theme.url;
            };

            containerList.appendChild(cardOpt);
        });

        setTimeout(() => {
            triggerIframePreviewWithTest(themes[0]);
        }, 50);

    } else {
        containerList.innerHTML = `<p style="color:#a0aec0; font-size:12px; padding: 15px; text-align:center;">Tidak ada tema kustom tersedia.</p>`;
        document.getElementById('modal-overlay-preview').src = 'about:blank';
    }

    if (key === 'hardware' && typeof ipcRenderer !== 'undefined') {
        ipcRenderer.invoke('get-hardware-specs').then((specs) => {
            cachedHardwareSpecs = specs;
            if (currentSelectedThemeUrl) {
                const activeTheme = themes.find(t => t.url === currentSelectedThemeUrl);
                if (activeTheme) triggerIframePreviewWithTest(activeTheme);
            }
        }).catch(err => console.error("Hardware check error:", err));
    }

    // Handler Tombol Apply
    document.getElementById('btn-modal-apply-copy').onclick = function (e) {
        if (e) { e.preventDefault(); e.stopPropagation(); }

        const finalSelect = document.getElementById(currentOldSelectId);
        if (finalSelect && currentSelectedThemeUrl) {
            finalSelect.value = currentSelectedThemeUrl;
            finalSelect.dispatchEvent(new Event('change'));
        }

        executeApplyAndCopy();
        document.getElementById('rv-overlay-modal').style.display = 'flex';

        const modalToast = document.getElementById('modal-toast-container');
        if (modalToast) {
            modalToast.innerHTML = `<div style="background:#333; color:white; padding:10px 20px; border-radius:8px;">Overlay berhasil diterapkan! ✨</div>`;
            setTimeout(() => { modalToast.innerHTML = ""; }, 3000);
        }
    };
}


// MEMBUAT TAMPILAN TAMBAHAN DI CARD KHUSUS ===============================================================================================================
function injectSpecialControls(key, container) {
    // 1. KONTROL KHUSUS: BRAND TEXT ROTATOR
    if (key === 'brandtext') {
        const savedTexts = localStorage.getItem('saved_brand_texts');
        if (savedTexts) {
            modalBrandTextsArray = JSON.parse(savedTexts);
        } else {
            modalBrandTextsArray = ["PROMO TERBARU DISINI", "FOLLOW UNTUK BONUS"];
        }

        const brandBox = document.createElement('div');
        brandBox.style = "background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        brandBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:8px;">
                <label style="font-size:12px; font-weight:600; color:#cbd5e1;">Kustomisasi Teks Promo:</label>
                <div style="display:flex; gap:8px;">
                    <input type="text" id="modal-input-brand-text" placeholder="Ketik teks promo baru..."
                        style="flex-grow:1; height: 34px; padding: 0 10px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 6px; font-size: 13px; outline:none;">
                    <button id="btn-modal-add-brand" style="background: #28a745; border: none; color: #fff; padding: 0 14px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: bold;">
                        ADD
                    </button>
                </div>
                <div id="modal-list-brand-text" style="background: rgba(0,0,0,0.2); border-radius: 6px; padding: 8px; min-height: 50px; font-size: 12px; display:flex; flex-wrap:wrap; gap:5px; align-content: flex-start; max-height: 120px; overflow-y:auto; border: 1px solid rgba(255,255,255,0.05);">
                    <span style="color: #666; font-style: italic;" id="modal-brand-placeholder">Belum ada teks ditambahkan...</span>
                </div>
            </div>
        `;
        container.appendChild(brandBox);

        renderModalBrandBadges();

        document.getElementById('btn-modal-add-brand').onclick = function () {
            const inputField = document.getElementById('modal-input-brand-text');
            const textValue = inputField.value.trim();
            if (textValue === "") return;

            modalBrandTextsArray.push(textValue);
            inputField.value = "";

            localStorage.setItem('saved_brand_texts', JSON.stringify(modalBrandTextsArray));
            renderModalBrandBadges();

            // SINKRONISASI KE PREVIEW (Gunakan fallback jika sendDataToPreviewIframe tidak terdefinisi)
            if (typeof sendDataToPreviewIframe === 'function') {
                sendDataToPreviewIframe();
            } else if (typeof triggerIframePreviewWithTest === 'function') {
                const themes = rvOverlayDatabase['brandtext'] || [];
                if (themes.length > 0) triggerIframePreviewWithTest(themes[0]);
            }
        };

        document.getElementById('modal-input-brand-text').addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                document.getElementById('btn-modal-add-brand').click();
            }
        });
    }

    // 2. KONTROL KHUSUS: NETWORK
    else if (key === 'network') {
        // PERBAIKAN: Ambil status asli dari toggle utama halaman luar SEBELUM membuat elemen baru
        const mainNetworkCheckbox = document.getElementById('main-toggle-network'); // <-- Sesuaikan dengan ID checkbox di halaman utama kamu
        const isCurrentlyChecked = mainNetworkCheckbox ? mainNetworkCheckbox.checked : false;

        const specialBox = document.createElement('div');
        specialBox.style = "background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        specialBox.innerHTML = `
            <div style="display:flex; justify-content:space-between; align-items:center;">
                <label style="font-size:13px; font-weight:600; color:#fff;">Status Service Internet:</label>
                <div style="display:flex; align-items:center; gap: 10px;">
                    <span id="network-status-text" style="font-weight:bold; font-size:12px; color:${isCurrentlyChecked ? '#22c55e' : '#9ca3af'};">${isCurrentlyChecked ? 'ON' : 'OFF'}</span>
                    <input type="checkbox" id="toggle-network" ${isCurrentlyChecked ? 'checked' : ''} onchange="handleNetworkToggleChange()" style="cursor:pointer; width:18px; height:18px;">
                </div>
            </div>
        `;
        container.appendChild(specialBox);

        // Update UI awal teks pendukung jika ada fungsi pendukungnya
        if (typeof updateNetworkStatusUI === 'function') {
            updateNetworkStatusUI(isCurrentlyChecked);
        }
    }

    // 3. KONTROL KHUSUS: FOLLOWER GOAL
    else if (key === 'followergoal') {
        const goalBox = document.createElement('div');
        goalBox.style = "background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        goalBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:6px;">
                <label style="font-size:12px; font-weight:600; color:#cbd5e1;">Target Followers Goal:</label>
                <div style="display:flex; gap:8px;">
                    <input type="number" id="modalTargetFollower" value="50" min="1"
                        style="flex-grow:1; height: 34px; padding: 0 10px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 6px; font-size: 13px; outline:none;">
                    <button id="btn-refresh-goal-preview" style="background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.15); color: #fff; padding: 0 12px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: 500;">
                        Set
                    </button>
                </div>
            </div>
        `;
        container.appendChild(goalBox);

        const oldMainInput = document.getElementById('targetFollower');
        if (oldMainInput) {
            document.getElementById('modalTargetFollower').value = oldMainInput.value;
        }

        document.getElementById('btn-refresh-goal-preview').onclick = function () {
            const themes = rvOverlayDatabase[currentModalKey] || [];
            if (themes.length > 0) {
                triggerIframePreviewWithTest(themes[0]);
            }

            if (oldMainInput) {
                oldMainInput.value = document.getElementById('modalTargetFollower').value;
            }
        };
    }

    // 4. KONTROL KHUSUS: SOCIAL MEDIA ROTATOR
    else if (key === 'social') {
        const savedSocials = JSON.parse(localStorage.getItem('saved_social_data')) || {
            ig: '', tt: '', yt: '', dc: '', duration: '5000', enabled: false
        };

        // Ditambahkan pemicu realtime triggerIframePreviewWithTest tiap kali input berubah (oninput)
        // Cukup gunakan sendDataToPreviewIframe agar iframe tidak ter-refresh saat mengetik
        const rotatorTrigger = "if(typeof sendDataToPreviewIframe === 'function') { sendDataToPreviewIframe(); }";

        const socialBox = document.createElement('div');
        socialBox.style = "background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        socialBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:10px; font-size: 13px; color: #cbd5e1;">
                <label style="font-weight:600; color:#fff;">Kustomisasi Akun Sosial Media:</label>
                
                <div style="display: flex; flex-direction: column; gap: 8px;">
                    <div>📷 Instagram
                        <input id="modal-social-ig" oninput="${rotatorTrigger}" placeholder="@username" value="${savedSocials.ig}" style="width:100%; height:34px; padding:0 10px; margin-top:4px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none;">
                    </div>
                    <div>🎵 TikTok
                        <input id="modal-social-tt" oninput="${rotatorTrigger}" placeholder="@username" value="${savedSocials.tt}" style="width:100%; height:34px; padding:0 10px; margin-top:4px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none;">
                    </div>
                    <div>▶ YouTube
                        <input id="modal-social-yt" oninput="${rotatorTrigger}" placeholder="@channel" value="${savedSocials.yt}" style="width:100%; height:34px; padding:0 10px; margin-top:4px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none;">
                    </div>
                    <div>💬 Discord
                        <input id="modal-social-dc" oninput="${rotatorTrigger}" placeholder="discord.gg/server" value="${savedSocials.dc}" style="width:100%; height:34px; padding:0 10px; margin-top:4px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none;">
                    </div>
                </div>

                <div style="margin-top: 5px;">
                    ⏱ Rotation Duration
                    <select id="modal-social-duration" onchange="${rotatorTrigger}" style="width:100%; height:34px; margin-top:4px; background:#1a1a1a; border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; padding:0 5px; outline:none;">
                        <option value="3000" ${savedSocials.duration === '3000' ? 'selected' : ''}>3 Seconds</option>
                        <option value="5000" ${savedSocials.duration === '5000' ? 'selected' : ''}>5 Seconds</option>
                        <option value="8000" ${savedSocials.duration === '8000' ? 'selected' : ''}>8 Seconds</option>
                        <option value="10000" ${savedSocials.duration === '10000' ? 'selected' : ''}>10 Seconds</option>
                    </select>
                </div>

                <div style="margin-top: 5px; display:flex; justify-content:space-between; align-items:center; background:rgba(0,0,0,0.15); padding:8px; border-radius:6px;">
                    <span>Status Aktif Overlay:</span>
                    <div style="display:flex; align-items:center; gap: 8px;">
                        <span id="modal-social-status-text" style="font-weight:bold; color: ${savedSocials.enabled ? '#22c55e' : '#9ca3af'};">${savedSocials.enabled ? 'ON' : 'OFF'}</span>
                        <input type="checkbox" id="modal-toggle-social" onchange="${rotatorTrigger}" ${savedSocials.enabled ? 'checked' : ''} style="cursor:pointer; width:18px; height:18px;">
                    </div>
                </div>
            </div>
            `;
        container.appendChild(socialBox);

        document.getElementById('modal-toggle-social').onchange = function () {
            const statusText = document.getElementById('modal-social-status-text');
            if (this.checked) {
                statusText.innerText = 'ON';
                statusText.style.color = '#22c55e';
            } else {
                statusText.innerText = 'OFF';
                statusText.style.color = '#9ca3af';
            }

            // Ganti jadi ini:
            if (typeof sendDataToPreviewIframe === 'function') {
                sendDataToPreviewIframe();
            }
        };
    }

    // 5. KONTROL KHUSUS: TEBAK KATA
    else if (key === 'tebakkata') {
        const tebakBox = document.createElement('div');
        tebakBox.style = "background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        tebakBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:10px;">
                <label style="font-size:13px; font-weight:600; color:#fff;">Game Tebak Kata:</label>
                <div style="display:flex; gap:8px;">
                    <input type="text" id="target-word" placeholder="KATA (ex: JERUK)"
                        style="flex-grow:1; height: 34px; padding: 0 10px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 6px; font-size: 13px; outline:none; text-transform: uppercase;">
                    <input type="text" id="target-hint" placeholder="PETUNJUK"
                        style="flex-grow:1; height: 34px; padding: 0 10px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 6px; font-size: 13px; outline:none;">
                </div>
                <div style="display:flex; gap:8px; margin-top:5px;">
                    <button id="btn-mulai-tebak" style="flex:1; background: #28a745; border: none; color: #fff; height: 34px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: bold;">
                        MULAI GAME
                    </button>
                </div>
            </div>
            `;
        container.appendChild(tebakBox);

        // Fungsi Mulai Game
        document.getElementById('btn-mulai-tebak').onclick = function () {
            const word = document.getElementById('target-word').value.trim();
            const hint = document.getElementById('target-hint').value.trim();

            if (!word) {
                if (typeof showToast === 'function') showToast("⚠️ Isi dulu katanya, brow!");
                else alert("⚠️ Isi dulu katanya, brow!");
                return;
            }

            // Buat sensor otomatis: JERUK jadi J _ _ _ K
            let sensor = word[0] + " " + "_ ".repeat(word.length - 2) + word[word.length - 1];

            // Kirim ke server lewat Socket
            if (typeof socket !== 'undefined') {
                socket.emit('start-tebak', {
                    word: word,
                    hint: hint || "Tidak ada petunjuk",
                    display: sensor.toUpperCase()
                });
            } else {
                console.warn("Socket.io tidak terhubung!");
            }

            if (typeof showToast === 'function') {
                showToast("🚀 Game Dimulai: " + word.toUpperCase());
            } else {
                alert("🚀 Game Dimulai: " + word.toUpperCase());
            }
        };

    }

    // 6. KONTROL KHUSUS: MONSTER RAID
    else if (key === 'monsterraid') {
        const monsterBox = document.createElement('div');
        monsterBox.style = "background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1);";
        monsterBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:10px;">
                <label style="font-size:13px; font-weight:600; color:#fff;">Game Monster Raid:</label>
                <div style="display:flex; gap:8px; align-items:center;">
                    <label style="font-size:12px; color:#cbd5e1; white-space:nowrap;">HP Monster:</label>
                    <input type="number" id="modal-monster-hp" placeholder="1000" value="1000" min="1"
                        style="flex-grow:1; height: 34px; padding: 0 10px; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.15); color: white; border-radius: 6px; font-size: 13px; outline:none;">
                </div>
                <div style="display:flex; gap:8px; margin-top:5px;">
                    <button id="btn-mulai-monster" style="flex:1; background: #dc3545; border: none; color: #fff; height: 34px; border-radius: 6px; font-size: 12px; cursor: pointer; font-weight: bold;">
                        MULAI GAME
                    </button>
                </div>
            </div>
            `;
        container.appendChild(monsterBox);

        // Fungsi Mulai Game
        document.getElementById('btn-mulai-monster').onclick = function () {
            const hp = document.getElementById('modal-monster-hp').value || 1000;

            // Kirim sinyal ke server lewat Socket
            if (typeof socket !== 'undefined') {
                socket.emit('start-monster', {
                    hp: parseInt(hp)
                });
            } else {
                console.warn("Socket.io tidak terhubung!");
            }

            if (typeof showToast === 'function') {
                showToast("👾 Game Monster Raid Dimulai! (HP: " + hp + ")");
            } else {
                alert("👾 Game Monster Raid Dimulai! (HP: " + hp + ")");
            }
        };
    }

    // 7. KONTROL KHUSUS: CHAT OVERLAY & CONTROLS
    else if (key === 'chatoverlay') {
        currentModalKey = 'chatoverlay';

        // Box dan isinya sudah dihapus, appendChild yang bikin error juga sudah dibuang.
        // Di sini kamu bisa langsung panggil fungsi atau logika menu card kamu selanjutnya.

    }
    // 8. KONTROL KHUSUS DOC CHATT OVERLAY
    else if (key === 'dockchat') {
        currentModalKey = 'dockchat';

        const leftMenuContainer = document.getElementById('rv-theme-list-vertical');

        if (leftMenuContainer) {
            // Biar form input tidak menumpuk saat ganti-ganti menu, hapus yang lama jika ada
            const oldControl = document.getElementById('dockchat-global-control');
            if (oldControl) oldControl.remove();

            const filterBox = document.createElement('div');
            filterBox.id = 'dockchat-global-control';
            filterBox.style = "background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1); font-family: 'Segoe UI', sans-serif;";

            filterBox.innerHTML = `
                    <label for="custom-limit" style="display: block; font-weight: 600; margin-bottom: 6px; color: #fff; font-size: 13px;">
                        ⚙️ Set Limit Tampilan Dock Chat:
                    </label>
                    <input type="number" id="custom-limit" value="15" min="1" max="50" 
                        style="width: 100%; height: 35px; padding: 0 10px; background: rgba(0,0,0,0.3); border: 1px solid rgba(255,255,255,0.2); color: #fff; border-radius: 6px; font-size: 13px; outline: none; box-sizing: border-box;">
                    <small style="color: #cbd5e1; display: block; margin-top: 4px; font-size: 11px;">
                        Maksimal baris chat sebelum otomatis terhapus.
                    </small>
                `;

            // Inject ke bagian paling atas menu kiri
            leftMenuContainer.prepend(filterBox);

            // Tambahkan variabel global untuk menyimpan state limit
            let globalDockChatLimit = 15;

            // Perbaikan fungsi patch agar lebih aman
            function patchThemeUrlWithLimit(url) {
                if (!url) return url;
                const cleanUrl = url.split('?')[0];
                return `${cleanUrl}?limit=${globalDockChatLimit}`;
            }

            // Update di dalam bagian 'dockchat'
            const inputLimit = document.getElementById('custom-limit');
            if (inputLimit) {
                inputLimit.addEventListener('input', (e) => {
                    globalDockChatLimit = e.target.value; // Update state global

                    // Update URL yang sedang aktif
                    currentSelectedThemeUrl = patchThemeUrlWithLimit(currentSelectedThemeUrl);

                    if (typeof sendDataToPreviewIframe === 'function') sendDataToPreviewIframe();
                });
            }

            // Intercept tombol Apply (Pastikan ini dijalankan setelah modal terbuka)
            const btnApplyCopy = document.getElementById('btn-modal-apply-copy');
            if (btnApplyCopy) {
                // Gunakan wrapper agar tidak merusak fungsi original
                const originalHandler = btnApplyCopy.onclick;
                btnApplyCopy.onclick = function (e) {
                    // Pastikan URL paling terakhir membawa limit
                    currentSelectedThemeUrl = patchThemeUrlWithLimit(currentSelectedThemeUrl);
                    if (originalHandler) originalHandler.call(this, e);
                };
            }
        }
    }
    // ====================================================================
    // KONTROL KHUSUS: DOCK GIFT (BENEFIT GIFT LIST) - PILIHAN A (PERMANENT FIX)
    // ====================================================================
    else if (key === 'dockgift') {
        currentModalKey = 'dockgift';

        // 1. Cek & Inisialisasi data default jika KEY benar-benar belum ada di komputer
        if (!localStorage.getItem('saved_gift_benefits')) {
            const defaultBenefits = [
                { icon: '🌹', benefit: 'Request 1 Lagu' },
                { icon: '☕', benefit: 'Main Bareng (Mabar)' },
                { icon: '🦁', benefit: 'VIP Selamanya + Atur Playlist' }
            ];
            localStorage.setItem('saved_gift_benefits', JSON.stringify(defaultBenefits));
        }

        // 2. Ambil data saat modal dibuka (Gunakan LET agar bisa ditambah/dikurangi berkali-kali)
        let savedGiftBenefits = JSON.parse(localStorage.getItem('saved_gift_benefits')) || [];

        const giftControlBox = document.createElement('div');
        giftControlBox.style = "background: rgba(255,255,255,0.05); padding: 15px; border-radius: 8px; margin-bottom: 15px; border: 1px solid rgba(255,255,255,0.1); font-family: 'Segoe UI', sans-serif;";

        giftControlBox.innerHTML = `
            <div style="display:flex; flex-direction:column; gap:12px;">
                <label style="font-size:13px; font-weight:600; color:#fff;">⚙️ Pengaturan Benefit Gift:</label>
                
                <!-- Form Input Penambahan/Update -->
                <div style="display:flex; flex-direction:column; gap:10px; background:rgba(0,0,0,0.2); padding:12px; border-radius:6px; border:1px solid rgba(255,255,255,0.05);">
                    
                    <!-- BARIS 1: Pilih Icon Gift -->
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <span style="font-size:11px; color:rgba(255,255,255,0.5); font-weight:500;">Pilih Icon Gift:</span>
                        <select id="modal-gift-icon" style="width:100%; height:36px; background:#1a1a1a; border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; padding:0 10px; font-size:14px; outline:none; cursor:pointer;">
                            <option value="🌹">🌹 Rose (Mawar)</option>
                            <option value="🍦">🍦 Ice Cream (Es Krim)</option>
                            <option value="🍩">🍩 Donut (Donat)</option>
                            <option value="🍿">🍿 Popcorn</option>
                            <option value="⚡">⚡ Lightning (Petir)</option>
                            <option value="🫰">🫰 Finger Heart</option>
                            <option value="🖐️">🖐️ High Five</option>
                            <option value="🌊">🌊 Wave (Ombak)</option>
                            <option value="🎈">🎈 Balloon</option>
                            <option value="☕">☕ Coffee (Kopi)</option>
                            <option value="🎸">🎸 Rock 'n' Roll / Gitar</option>
                            <option value="🕶️">🕶️ Cool Glasses (Kacamata)</option>
                            <option value="🔥">🔥 Fire (Api/Hot)</option>
                            <option value="💎">💎 Diamond (Permata)</option>
                            <option value="🎂">🎂 Birthday Cake</option>
                            <option value="🏆">🏆 Trophy (Piala)</option>
                            <option value="👑">👑 Crown (Mahkota)</option>
                            <option value="🦁">🦁 Lion (Singa)</option>
                            <option value="🐳">🐳 Whale (Paus)</option>
                            <option value="🚀">🚀 Rocket (Roket)</option>
                            <option value="🪐">🪐 Universe (Alam Semesta)</option>
                            <option value="🏰">🏰 Castle (Istana)</option>
                            <option value="✈️">✈️ Private Jet</option>
                            <option value="🏎️">🏎️ Sports Car (Mobil Balap)</option>
                        </select>
                    </div>
                    
                    <!-- BARIS 2: Input Keterangan/Benefit -->
                    <div style="display:flex; flex-direction:column; gap:4px;">
                        <span style="font-size:11px; color:rgba(255,255,255,0.5); font-weight:500;">Keterangan / Benefit:</span>
                        <input type="text" id="modal-gift-benefit" placeholder="Contoh: Play 1 Musik / Mabar / Atur Playlist" 
                            style="width:100%; height:36px; padding:0 10px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; font-size:13px; outline:none; box-sizing:border-box;">
                    </div>
                    
                    <!-- BARIS 3: Tombol ADD -->
                    <button id="btn-modal-add-gift" style="width:100%; background:#28a745; border:none; color:#fff; height:36px; border-radius:6px; font-size:13px; cursor:pointer; font-weight:bold; transition: background 0.2s; margin-top:4px;">
                        + Tambah Benefit Gift
                    </button>
                </div>

                <!-- Container List Item Gift -->
                <div id="modal-list-gift-items" style="background:rgba(0,0,0,0.2); border-radius:6px; padding:8px; min-height:60px; max-height:150px; overflow-y:auto; display:flex; flex-direction:column; gap:6px; border:1px solid rgba(255,255,255,0.05);">
                </div>
            </div>
        `;
        container.appendChild(giftControlBox);

        // Fungsi internal untuk me-render daftar list di dalam modal
        function renderModalGiftList() {
            const listContainer = document.getElementById('modal-list-gift-items');
            if (!listContainer) return;
            listContainer.innerHTML = "";

            // BROW FIX: Render murni looping dari isi variabel memori saat ini
            savedGiftBenefits.forEach((item, index) => {
                const row = document.createElement('div');
                row.style = "display:flex; align-items:center; background:rgba(255,255,255,0.05); padding:6px 10px; border-radius:4px; border:1px solid rgba(255,255,255,0.08); justify-content:space-between;";

                row.innerHTML = `
                    <div style="display:flex; align-items:center; gap:8px; font-size:12px; color:#cbd5e1;">
                        <span style="font-size:15px;">${item.icon}</span>
                        <span style="font-weight:500;">${item.benefit}</span>
                    </div>
                    <span style="color:#ef4444; cursor:pointer; font-weight:bold; font-size:14px; padding:0 4px;" class="btn-del-gift" data-index="${index}">×</span>
                `;
                listContainer.appendChild(row);
            });

            // Pasang event listener hapus
            listContainer.querySelectorAll('.btn-del-gift').forEach(btn => {
                btn.onclick = function () {
                    const idx = parseInt(this.getAttribute('data-index'));

                    // Potong data dari array utama
                    savedGiftBenefits.splice(idx, 1);
                    // Langsung simpan perubahan terbaru ke storage fisik komputer
                    localStorage.setItem('saved_gift_benefits', JSON.stringify(savedGiftBenefits));

                    renderModalGiftList();
                    sendDataToPreviewIframe(); // Kirim realtime ke iframe preview
                };
            });
        }

        // Jalankan render list pertama kali
        renderModalGiftList();

        // Aksi tombol ADD Gift Benefit
        document.getElementById('btn-modal-add-gift').onclick = function () {
            const icon = document.getElementById('modal-gift-icon').value;
            const benefit = document.getElementById('modal-gift-benefit').value.trim();

            if (benefit === "") return;

            // BROW FIX: Masukkan data baru langsung ke array utama yang sama
            savedGiftBenefits.push({ icon, benefit });

            // Kunci semua daftar array utuh (bukan cuma satu data) ke localStorage
            localStorage.setItem('saved_gift_benefits', JSON.stringify(savedGiftBenefits));

            // Reset field input benefit saja
            document.getElementById('modal-gift-benefit').value = "";

            renderModalGiftList();
            sendDataToPreviewIframe(); // Kirim realtime ke iframe preview
        };
    }

    // ====================================================================
    // KONTROL KHUSUS: GIFT MILESTONE (TARGET GOAL GIFT)
    // ====================================================================
    else if (key === 'milestone') {
        currentModalKey = 'milestone';

        // Ambil data array dari localStorage, jika kosong default-nya kasih 1 contoh
        let savedMilestones = JSON.parse(localStorage.getItem('saved_gift_milestones')) || [
            { id: Date.now(), title: 'Target Singa Terbang!', giftName: 'Lion', giftIcon: '🦁', targetValue: 50, currentValue: 0 }
        ];

        // Daftar lengkap Preset Gift TikTok menggunakan Emoji
        const giftPresets = [
            // --- Gift Murah / Populer (1 - 99 Coins) ---
            { emoji: '🌹', name: 'Rose (Mawar)', value: 'Rose' },
            { emoji: '🍦', name: 'Ice Cream (Es Krim)', value: 'Ice Cream' },
            { emoji: '🍩', name: 'Donut (Donat)', value: 'Donut' },
            { emoji: '🍿', name: 'Popcorn', value: 'Popcorn' },
            { emoji: '⚡', name: 'Lightning (Petir)', value: 'Lightning' },
            { emoji: '🫰', name: 'Finger Heart', value: 'Finger Heart' },
            { emoji: '✋', name: 'High Five', value: 'High Five' },
            { emoji: '🌊', name: 'Wave (Ombak)', value: 'Wave' },
            { emoji: '🎈', name: 'Balloon (Balon)', value: 'Balloon' },
            { emoji: '☕', name: 'Coffee (Kopi)', value: 'Coffee' },
            { emoji: '🎵', name: 'TikTok Note', value: 'TikTok Note' },
            { emoji: '🐼', name: 'Panda', value: 'Panda' },
            { emoji: '🌷', name: 'Tulip', value: 'Tulip' },
            { emoji: '🧸', name: 'Teddy Bear', value: 'Teddy Bear' },
            { emoji: '🍭', name: 'Lollipop', value: 'Lollipop' },
            { emoji: '🍫', name: 'Chocolate (Cokelat)', value: 'Chocolate' },
            { emoji: '🫶', name: 'Heart Hands', value: 'Heart Hands' },
            { emoji: '🎮', name: 'GG (Game Controller)', value: 'GG' },

            // --- Gift Menengah (100 - 999 Coins) ---
            { emoji: '🎸', name: 'Rock n Roll / Gitar', value: 'Guitar' },
            { emoji: '🕶️', name: 'Cool Glasses (Kacamata)', value: 'Cool Glasses' },
            { emoji: '🔥', name: 'Fire (Api/Hot)', value: 'Fire' },
            { emoji: '🎂', name: 'Birthday Cake', value: 'Birthday Cake' },
            { emoji: '🏆', name: 'Trophy (Piala)', value: 'Trophy' },
            { emoji: '💍', name: 'Diamond Ring (Cincin)', value: 'Ring' },
            { emoji: '🕊️', name: 'Paper Crane (Burung Kertas)', value: 'Paper Crane' },
            { emoji: '🦢', name: 'Swan (Angsa)', value: 'Swan' },
            { emoji: '💸', name: 'Money Rain (Hujan Uang)', value: 'Money Rain' },
            { emoji: '🎆', name: 'Fireworks (Kembang Api)', value: 'Fireworks' },

            // --- Gift Sultan / VIP (1,000+ Coins) ---
            { emoji: '💎', name: 'Diamond (Permata)', value: 'Diamond' },
            { emoji: '👑', name: 'Crown (Mahkota)', value: 'Crown' },
            { emoji: '🦁', name: 'Lion (Singa)', value: 'Lion' },
            { emoji: '🐋', name: 'Whale (Paus)', value: 'Whale' },
            { emoji: '🚀', name: 'Rocket (Roket)', value: 'Rocket' },
            { emoji: '🏎️', name: 'Sports Car (Mobil Balap)', value: 'Sports Car' },
            { emoji: '🛥️', name: 'Yacht (Kapal Pesiar)', value: 'Yacht' },
            { emoji: '🏰', name: 'Castle (Istana)', value: 'Castle' },
            { emoji: '🐉', name: 'Dragon (Naga)', value: 'Dragon' },
            { emoji: '🪐', name: 'TikTok Universe', value: 'Universe' }
        ];

        // Container Utama
        const mainMilestoneBox = document.createElement('div');
        mainMilestoneBox.style = "font-family: 'Segoe UI', sans-serif; display: flex; flex-direction: column; gap: 12px;";

        // Wrapper List Form Target
        const listContainer = document.createElement('div');
        listContainer.id = 'milestone-list-container';
        listContainer.style = "max-height: 320px; overflow-y: auto; padding-right: 4px; display: flex; flex-direction: column; gap: 10px;";
        mainMilestoneBox.appendChild(listContainer);

        // Tombol Aksi Bawah
        const actionBox = document.createElement('div');
        actionBox.innerHTML = `
            <button id="btn-add-milestone-row" style="width:100%; background:rgba(255,255,255,0.1); border:1px dashed rgba(255,255,255,0.3); color:#fff; height:34px; border-radius:6px; font-size:12px; cursor:pointer; font-weight:bold; margin-bottom: 8px;">
                ➕ Tambah Target Gift Baru
            </button>
            <button id="btn-save-milestone-preview" style="width:100%; background:#28a745; border:none; color:#fff; height:36px; border-radius:6px; font-size:13px; cursor:pointer; font-weight:bold;">
                Simpan & Refresh Preview
            </button>
        `;
        mainMilestoneBox.appendChild(actionBox);
        container.appendChild(mainMilestoneBox);

        // Fungsi Render Ulang List Form Target berdasarkan Data Array
        function renderMilestoneRows() {
            listContainer.innerHTML = '';
            savedMilestones.forEach((milestone, index) => {
                const row = document.createElement('div');
                row.style = "background: rgba(255,255,255,0.05); padding: 12px; border-radius: 8px; border: 1px solid rgba(255,255,255,0.1); position: relative; display: flex; flex-direction: column; gap: 8px;";

                // Generasi Opsi Dropdown
                let selectOptions = '';
                giftPresets.forEach(g => {
                    const isSelected = g.value === milestone.giftName ? 'selected' : '';
                    selectOptions += `<option value="${g.value}" data-icon="${g.emoji}" ${isSelected} style="background:#1e1e24; color:#fff;">${g.emoji} ${g.name}</option>`;
                });

                row.innerHTML = `
                    <button class="btn-delete-milestone" data-index="${index}" style="position:absolute; top:8px; right:8px; background:none; border:none; color:#ff4d4d; cursor:pointer; font-size:14px; padding:2px 6px;">❌</button>
                    
                    <div style="font-size:11px; font-weight:bold; color:#a78bfa;">TARGET #${index + 1}</div>
                    
                    <div>Judul Target:
                        <input class="milestone-title" value="${milestone.title}" placeholder="Contoh: Upgrade PC" style="width:100%; height:30px; padding:0 8px; margin-top:3px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none; font-size:12px;">
                    </div>
                    
                    <div>Pilih Gift:
                        <select class="milestone-gift" style="width:100%; height:30px; padding:0 8px; margin-top:3px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none; cursor:pointer; font-size:12px;">
                            ${selectOptions}
                        </select>
                    </div>

                    <div style="display:flex; gap:6px;">
                        <div style="flex:1;">Target:
                            <input type="number" class="milestone-target" value="${milestone.targetValue}" min="1" style="width:100%; height:30px; padding:0 8px; margin-top:3px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none; font-size:12px;">
                        </div>
                        <div style="flex:1;">Mulai dari:
                            <input type="number" class="milestone-current" value="${milestone.currentValue}" min="0" style="width:100%; height:30px; padding:0 8px; margin-top:3px; background:rgba(0,0,0,0.2); border:1px solid rgba(255,255,255,0.15); color:white; border-radius:6px; outline:none; font-size:12px;">
                        </div>
                    </div>
                `;

                listContainer.appendChild(row);
            });

            // Handle Tombol Hapus Row Target
            document.querySelectorAll('.btn-delete-milestone').forEach(btn => {
                btn.onclick = function () {
                    const idx = parseInt(this.getAttribute('data-index'));
                    savedMilestones.splice(idx, 1);
                    renderMilestoneRows();
                };
            });
        }

        // Jalankan render pertama kali
        renderMilestoneRows();

        // Handle Aksi Tambah Target Baru
        document.getElementById('btn-add-milestone-row').onclick = function () {
            savedMilestones.push({
                id: Date.now(),
                title: 'Target Baru',
                giftName: 'Rose',
                giftIcon: '🌹',
                targetValue: 100,
                currentValue: 0
            });
            renderMilestoneRows();
            // Otomatis scroll ke item paling bawah yang baru ditambahkan
            listContainer.scrollTop = listContainer.scrollHeight;
        };

        // Handle Aksi Tombol Simpan & Refresh Preview
        document.getElementById('btn-save-milestone-preview').onclick = function () {
            const updatedMilestones = [];
            const rows = listContainer.children;

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const selectEl = row.querySelector('.milestone-gift');
                const selectedOption = selectEl.options[selectEl.selectedIndex];
                const giftEmoji = selectedOption.getAttribute('data-icon');

                updatedMilestones.push({
                    id: Date.now() + i,
                    title: row.querySelector('.milestone-title').value.trim(),
                    giftName: selectEl.value,
                    giftIcon: giftEmoji,
                    targetValue: parseInt(row.querySelector('.milestone-target').value) || 100,
                    currentValue: parseInt(row.querySelector('.milestone-current').value) || 0
                });
            }

            // Simpan Array data ke localStorage
            localStorage.setItem('saved_gift_milestones', JSON.stringify(updatedMilestones));

            // 🔥 FIX 1: TEMBAKKAN LANGSUNG KE SERVER REAL-TIME LEWAT SOCKET
            // Ini yang bikin overlay OBS dan preview langsung berubah saat itu juga!
            if (typeof socket !== 'undefined') {
                socket.emit('update-milestones-data', updatedMilestones);
                console.log("🚀 [SOCKET] Berhasil mengirim array milestone terbaru ke server:", updatedMilestones);
            } else {
                console.error("❌ Variabel 'socket' tidak ditemukan. Pastikan client socket.io sudah di-inisialisasi di atas.");
            }

            // Trigger preview ke iframe lokal (bawaan kode kamu)
            const themes = rvOverlayDatabase['milestone'] || [];
            if (themes.length > 0) {
                const iframe = document.getElementById('preview-iframe');
                if (iframe && iframe.contentWindow && typeof iframe.contentWindow.showMultiMilestone === 'function') {
                    iframe.contentWindow.showMultiMilestone(updatedMilestones);
                } else if (themes[0]) {
                    triggerIframePreviewWithTest(themes[0]);
                }
            }
        }; // Akhir dari btn-save-milestone-preview.onclick
    }
}

//=================================================================================================================================

// ========================================================
// FUNGSI PEMBANTU (DITARUH DI LUAR INJECTSPECIALCONTROLS)
// ========================================================

// 1. Fungsi pembantu untuk menggambar list badge teks di dalam modal
function renderModalBrandBadges() {
    const listContainer = document.getElementById('modal-list-brand-text');
    if (!listContainer) return;

    if (modalBrandTextsArray.length === 0) {
        listContainer.innerHTML = `<span style="color: #666; font-style: italic;" id="modal-brand-placeholder">Belum ada teks ditambahkan...</span>`;
        return;
    }

    listContainer.innerHTML = "";
    modalBrandTextsArray.forEach((text, index) => {
        const badge = document.createElement('div');
        badge.style = "background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 4px 8px; border-radius: 4px; display: flex; align-items: center; gap: 6px; font-size:11px;";
        badge.innerHTML = `
                <span class="modal-brand-item-text">${text}</span>
                <span style="color: #ef4444; cursor: pointer; font-weight: bold; font-size:12px;" onclick="removeModalBrandText(${index})">×</span>
            `;
        listContainer.appendChild(badge);
    });
}

// 2. PERBAIKAN: Gabungkan fungsi hapus menjadi SATU (Tidak duplikat lagi)
window.removeModalBrandText = function (index) {
    modalBrandTextsArray.splice(index, 1);

    // Update data di penyimpanan permanen
    localStorage.setItem('saved_brand_texts', JSON.stringify(modalBrandTextsArray));
    renderModalBrandBadges();

    // Kirim perubahan terbaru secara realtime ke iframe
    sendDataToPreviewIframe();
};

// 3. PERBAIKAN UTAMA: Buat fungsi sync menjadi dinamis agar OVERLAY SOCIAL & DOCKCHAT ikut muncul secara realtime
function sendDataToPreviewIframe() {
    const iframe = document.getElementById('modal-overlay-preview');
    if (!iframe || !iframe.contentWindow) {
        console.log("Element iframe modal-overlay-preview belum siap atau tidak ditemukan.");
        return;
    }

    // 🔥 BUNGKUS DENGAN SETTIMEOUT:
    // Mengubah eksekusi menjadi asynchronous agar tidak memblokir / me-ngefreeze UI modal (Delay hilang)
    setTimeout(() => {
        try {
            // JIKA SEDANG MEMBUKA MODAL BRAND TEXT
            if (currentModalKey === 'brandtext') {
                if (typeof iframe.contentWindow.updateBrandTexts === 'function') {
                    iframe.contentWindow.updateBrandTexts(modalBrandTextsArray);
                    console.log("Sync Brand Text sukses:", modalBrandTextsArray);
                }
            }
            // JIKA SEDANG MEMBUKA MODAL SOCIAL MEDIA
            else if (currentModalKey === 'social') {
                const currentSocialData = {
                    ig: document.getElementById('modal-social-ig')?.value || '',
                    tt: document.getElementById('modal-social-tt')?.value || '',
                    yt: document.getElementById('modal-social-yt')?.value || '',
                    dc: document.getElementById('modal-social-dc')?.value || '',
                    duration: document.getElementById('modal-social-duration')?.value || '5000',
                    enabled: document.getElementById('modal-toggle-social') ? document.getElementById('modal-toggle-social').checked : true
                };

                if (typeof iframe.contentWindow.showSocial === 'function') {
                    iframe.contentWindow.showSocial(currentSocialData);
                }
                iframe.contentWindow.dispatchEvent(new CustomEvent("updateSocial", { detail: currentSocialData }));
            }
            // 🔥 JIKA SEDANG MEMBUKA MODAL CHAT OVERLAY
            else if (currentModalKey === 'chatoverlay') {
                const currentChatData = {
                    theme: document.getElementById('selectedTheme')?.value || 'darkcapsul',
                    layout: document.getElementById('chatLayout')?.value || 'vertical',
                    limit: 1, // SET FIX JADI 1 DI SINI BROW!
                    timer: parseInt(document.getElementById('chatTimer')?.value || '15')
                };

                if (typeof iframe.contentWindow.updateChatSettings === 'function') {
                    iframe.contentWindow.updateChatSettings(currentChatData);
                }
                iframe.contentWindow.dispatchEvent(new CustomEvent("updateChatOverlay", { detail: currentChatData }));
                iframe.contentWindow.postMessage(currentChatData, '*');

                console.log("Sync Chat Box sukses");
            }
            // 🔥 TAMBAHAN BARU: JIKA SEDANG MEMBUKA MODAL DOCK CHAT OVERLAY
            else if (currentModalKey === 'dockchat') {
                const currentLimitInput = document.getElementById('custom-limit');
                const listTema = rvOverlayDatabase.dockchat || [];

                // 🛠️ FIX 1: Persempit area pencarian DOM hanya ke dalam modal (Biar tidak nyasar ke sidebar utama)
                const activeMenuEl = document.querySelector('.rv-modal-sidebar .theme-card-option.active')
                    || document.querySelector('.theme-card-option[style*="border: 1px solid"]');

                // 🛠️ FIX 2: Ganti 'strong' menjadi 'h5' karena judul tema dibungkus tag <h5>
                const activeThemeName = activeMenuEl ? activeMenuEl.querySelector('h5')?.innerText : 'Horizontal';

                const currentTheme = listTema.find(t => t.name.toLowerCase() === (activeThemeName || '').toLowerCase()) || listTema[0];

                const currentDockData = {
                    theme: currentTheme ? currentTheme.url : '',
                    limit: parseInt(currentLimitInput ? currentLimitInput.value : '15'),
                    layout: 'vertical'
                };

                // Kirim perubahan ke internal iframe preview
                if (typeof iframe.contentWindow.updateChatSettings === 'function') {
                    iframe.contentWindow.updateChatSettings(currentDockData);
                }
                iframe.contentWindow.dispatchEvent(new CustomEvent("updateDockChat", { detail: currentDockData }));
                iframe.contentWindow.postMessage(currentDockData, '*');

                console.log("Sync Dock Chat sukses");
            }
            // 🔥 JIKA SEDANG MEMBUKA MODAL BENEFIT GIFT OVERLAY (PILHAN A)
            else if (currentModalKey === 'dockgift') {
                const savedGiftBenefits = JSON.parse(localStorage.getItem('saved_gift_benefits')) || [];

                // Jika file html tema kamu memiliki fungsi khusus untuk menerima data
                if (typeof iframe.contentWindow.updateGiftBenefits === 'function') {
                    iframe.contentWindow.updateGiftBenefits(savedGiftBenefits);
                }

                // Atau kirim via custom event / postMessage agar dibaca file tema
                iframe.contentWindow.dispatchEvent(new CustomEvent("updateGiftOverlay", { detail: savedGiftBenefits }));
                iframe.contentWindow.postMessage({ type: 'UPDATE_GIFT', data: savedGiftBenefits }, '*');

                console.log("Sync Daftar Gift sukses:", savedGiftBenefits);
            }
        } catch (e) {
            console.log("Gagal sinkronisasi karena beda origin atau iframe belum termuat sempurna:", e);
        }
    }, 10); // Jeda microtask 10ms agar render UI utama jalan duluan
}

//============================================================================================================================================

async function handleNetworkToggleChange() {
    const isEnabled = document.getElementById('toggle-network').checked;
    updateNetworkStatusUI(isEnabled);

    const nativeCheckbox = document.getElementById('toggle-network-main');
    if (nativeCheckbox) {
        nativeCheckbox.checked = isEnabled;
    }

    // 🛠️ PERBAIKAN 1: Tentukan baseUrl yang aman untuk Electron Backend
    // Jika origin-nya bukan localhost (misal file://), paksa ke port backend Express kamu
    let baseUrl = window.location.origin;
    if (baseUrl.includes('localhost') === false) {
        baseUrl = 'http://localhost:3000'; // Sesuaikan dengan port server backend kamu
    }

    try {
        if (isEnabled) {
            // 🛠️ PERBAIKAN 2: Gunakan full URL absolute agar fetch tidak tersesat ke file://
            await fetch(`${baseUrl}/network/start`);

            if (typeof showToast === "function") showToast("Service Network Monitor Diaktifkan!");

            // 🛠️ PERBAIKAN 3: Buang window.location.origin, gunakan path relatif murni agar bebas timeout 4 detik
            document.getElementById('modal-overlay-preview').src = "/themes/utils/network.html?t=" + Date.now();
        } else {
            // Gunakan full URL absolute untuk stop juga
            await fetch(`${baseUrl}/network/stop`);

            if (typeof showToast === "function") showToast("Service Network Monitor Dimatikan.");
            document.getElementById('modal-overlay-preview').src = "about:blank";
        }
    } catch (err) {
        console.error("Gagal menembak API Network Backend:", err);
    }
}

function updateNetworkStatusUI(enabled) {
    const statusText = document.getElementById('network-status-text');
    if (!statusText) return;
    if (enabled) {
        statusText.innerText = 'ON';
        statusText.style.color = '#22c55e';
    } else {
        statusText.innerText = 'OFF';
        statusText.style.color = '#9ca3af';
    }
}

// 3. Fungsi Pembantu: Muat Iframe + Tempel Query Parameter / Jalankan Test Func
function triggerIframePreviewWithTest(themeObj) {
    const iframe = document.getElementById('modal-overlay-preview');
    if (!iframe) return;

    currentSelectedThemeUrl = themeObj.url;

    // 🔥 PERBAIKAN 1: Buang window.location.origin agar tidak memicu DNS/Host timeout 4 detik di Electron
    let finalRenderUrl = themeObj.url + "?preview=true";

    if (currentModalKey === 'network') {
        const isEnabled = document.getElementById('toggle-network') ? document.getElementById('toggle-network').checked : false;
        if (!isEnabled) {
            iframe.src = 'about:blank';
            return;
        }
    }

    if (currentModalKey === 'hardware' && cachedHardwareSpecs && !cachedHardwareSpecs.error) {
        finalRenderUrl += `&cpu=${encodeURIComponent(cachedHardwareSpecs.cpu)}&gpu=${encodeURIComponent(cachedHardwareSpecs.gpu)}&ram=${cachedHardwareSpecs.ram}`;
    }

    // 🔍 KUNCI DEBUG: Intip URL aslinya di console biar kelihatan kalau ada path yang typo
    console.log("Menampilkan Preview dari URL:", finalRenderUrl);

    // 🔥 PERBAIKAN 2: Definisikan .onload LEBIH DULU sebelum src-nya diisi
    iframe.onload = () => {

        // 🛠️ TAMBAHAN FITUR: Auto-Scale Konten Agar Fit & Tidak Terpotong di Frame Preview
        try {
            const doc = iframe.contentDocument || iframe.contentWindow.document;

            if (doc && doc.body) {
                const style = doc.createElement('style');

                style.innerHTML = `
            html, body {
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
                height: 100% !important;
                overflow: hidden !important;
                background: transparent !important;
            }

            img, canvas, video {
                max-width: 100%;
                height: auto;
            }
        `;

                if (currentModalKey === 'musicoverlay') {
                    style.innerHTML += `
                .overlay {
                    width: 1280px !important;
                    height: 720px !important;
                    min-width: 1280px !important;
                    min-height: 720px !important;
                    padding: 0 !important;
                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;
                }

                .unit {
                    width: 1180px !important;
                    min-width: 1180px !important;
                    min-height: 420px !important;
                    aspect-ratio: 16 / 9 !important;
                    grid-template-columns: minmax(0, 1.08fr) minmax(300px, .92fr) !important;
                    gap: 42px !important;
                    padding: 42px !important;
                }

                .deck {
                    min-height: 340px !important;
                    padding: 28px !important;
                }

                .info {
                    border-left: 1px solid rgba(241, 240, 220, .36) !important;
                    border-top: 0 !important;
                }

                .info::before {
                    display: block !important;
                }

                .record-zone {
                    display: grid !important;
                }

                .controls {
                    display: flex !important;
                }

                .waveform,
                .next {
                    display: flex !important;
                }

                .next {
                    flex-direction: column !important;
                }

                .platter {
                    width: 300px !important;
                }

                .album-art {
                    width: 240px !important;
                }
            `;
                }

                doc.head.appendChild(style);

                setTimeout(() => {
                    const frameWidth = iframe.clientWidth || iframe.offsetWidth;
                    const frameHeight = iframe.clientHeight || iframe.offsetHeight;

                    if (currentModalKey === 'musicoverlay') {
                        const overlay = doc.querySelector('.overlay');
                        if (!overlay) return;

                        const baseWidth = 1280;
                        const baseHeight = 720;

                        // Samakan dengan preview Request Musik.
                        // Ubah ke 0.40 jika ingin sedikit lebih besar.
                        const previewScale = 0.40;

                        // Body menjadi viewport kecil, overlay menjadi kanvas landscape.
                        doc.body.style.display = 'flex';
                        doc.body.style.alignItems = 'center';
                        doc.body.style.justifyContent = 'center';
                        doc.body.style.width = '100%';
                        doc.body.style.height = '100%';
                        doc.body.style.overflow = 'hidden';

                        overlay.style.width = `${baseWidth}px`;
                        overlay.style.height = `${baseHeight}px`;
                        overlay.style.minWidth = `${baseWidth}px`;
                        overlay.style.minHeight = `${baseHeight}px`;
                        overlay.style.flex = `0 0 ${baseWidth}px`;
                        overlay.style.transformOrigin = 'center center';
                        overlay.style.transform = `scale(${previewScale})`;
                        overlay.style.margin = '0';
                    } else {
                        // Auto-scale lama untuk tema selain Music Overlay.
                        const contentWidth = doc.body.scrollWidth;
                        const contentHeight = doc.body.scrollHeight;

                        if (contentWidth > frameWidth || contentHeight > frameHeight) {
                            const scaleX = frameWidth / contentWidth;
                            const scaleY = frameHeight / contentHeight;
                            const finalScale = Math.min(scaleX, scaleY) * 0.95;

                            if ('zoom' in doc.body.style) {
                                doc.body.style.zoom = finalScale;
                            } else {
                                doc.body.style.transform = `scale(${finalScale})`;
                                doc.body.style.transformOrigin = 'top center';
                            }
                        }
                    }

                    iframe.style.visibility = 'visible';
                }, 80);
            }
        } catch (err) {
            iframe.style.visibility = 'visible';
            console.warn(
                'Gagal menjalankan auto-scale preview (Kemungkinan Cross-Origin):',
                err
            );
        }




        const testFuncName = themeObj.testFunc;

        if (testFuncName && iframe.contentWindow) {

            // 🌟 TAMBAHKAN KONDISI BARU INI BROW:
            if (currentModalKey === 'dockgift') {
                // Ambil data gift benefit dari localStorage (Coffee, Lion, dkk)
                const savedGiftBenefits = JSON.parse(localStorage.getItem('saved_gift_benefits')) || [
                    { icon: '🌹', name: 'Rose', benefit: 'Request 1 Lagu' },
                    { icon: '☕', name: 'Coffee', benefit: 'Main Bareng (Mabar)' },
                    { icon: '🦁', name: 'Lion', benefit: 'VIP Selamanya + Atur Playlist' }
                ];

                // Panggil fungsi sinkronisasi bawaan kamu agar data langsung terlempar ke iframe
                if (typeof sendDataToPreviewIframe === 'function') {
                    sendDataToPreviewIframe();
                }
            }

            // 1. Kondisi untuk Top Gift
            if (testFuncName === 'updateLeaderboard' && typeof iframe.contentWindow[testFuncName] === 'function') {
                iframe.contentWindow[testFuncName](rvTopGiftTestData);
            }
            // 2. Kondisi untuk Top Like
            else if (testFuncName === 'renderLeaderboard' && typeof iframe.contentWindow[testFuncName] === 'function') {
                iframe.contentWindow[testFuncName](rvTopLikeTestData);
            }
            // 3. UNTUK FOLLOWER GOAL
            else if (testFuncName === 'showGoal' && typeof iframe.contentWindow[testFuncName] === 'function') {
                const modalInput = document.getElementById('modalTargetFollower');
                const targetValue = modalInput ? parseInt(modalInput.value) : 50;

                const goalTestData = {
                    target: targetValue,
                    current: Math.floor(targetValue * 0.4),
                    title: "Follower Goal"
                };
                iframe.contentWindow[testFuncName](goalTestData);
            }
            // 4. UNTUK FOLLOWER
            else if (testFuncName === 'showFollower' && typeof iframe.contentWindow[testFuncName] === 'function') {
                const followerTestData = {
                    nickname: "Sultan Parepare",
                    username: "sultan_parepare",
                    profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png",
                    message: "Baru saja mengikuti!"
                };

                iframe.contentWindow[testFuncName](followerTestData);
                iframe.contentWindow.dispatchEvent(new CustomEvent("previewFollow", { detail: followerTestData }));
                iframe.contentWindow.dispatchEvent(new CustomEvent("showFollower", { detail: followerTestData }));
            }
            // 5. UNTUK JOIN & GIFT ALERT
            else if ((testFuncName === 'showJoin' || testFuncName === 'showGift') && typeof iframe.contentWindow[testFuncName] === 'function') {
                const fullAlertData = {
                    nickname: "Sultan_Join",
                    uniqueId: "sultan_parepare",
                    user: "sultan_parepare",
                    profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png",
                    giftName: "Casino Dice",
                    diamondCount: 100,
                    repeatCount: 1,
                    giftIconUrl: "https://www.w3schools.com/howto/img_avatar.png"
                };

                iframe.contentWindow[testFuncName](fullAlertData);
                iframe.contentWindow.dispatchEvent(new CustomEvent("previewJoin", { detail: fullAlertData }));
                iframe.contentWindow.dispatchEvent(new CustomEvent("previewGift", { detail: fullAlertData }));
            }
            // 6. UNTUK BRAND TEXT
            else if (testFuncName === 'showBrand' || testFuncName === 'updateBrandTexts') {
                const savedTexts = localStorage.getItem('saved_brand_texts');
                const finalData = savedTexts ? JSON.parse(savedTexts) : modalBrandTextsArray;
                const testDataArray = finalData.length > 0 ? finalData : ["PROMO TERBARU DISINI", "HOMEIT INTERNET CEPAT"];

                if (typeof iframe.contentWindow.updateBrandTexts === 'function') {
                    iframe.contentWindow.updateBrandTexts(testDataArray);
                }
            }
            // 7. Kondisi tema social media
            else if (testFuncName === 'showSocial' && typeof iframe.contentWindow[testFuncName] === 'function') {
                const savedSocials = JSON.parse(localStorage.getItem('saved_social_data')) || {
                    ig: '@default_ig', tt: '@default_tt', yt: 'Default Channel', dc: 'discord.gg/default', duration: '5000'
                };
                iframe.contentWindow[testFuncName](savedSocials);
            }
            // 8. KHUSUS CHAT OVERLAY (Anime Style & Avatar Box)
            else if (testFuncName === 'dockchat') {
                const config = {
                    layout: 'vertical',
                    timer: 15,
                    limit: 1
                };

                if (typeof iframe.contentWindow.updateChatSettings === 'function') {
                    iframe.contentWindow.updateChatSettings(config);
                }

                if (typeof iframe.contentWindow.triggerDisplayChatCard === 'function') {
                    iframe.contentWindow.triggerDisplayChatCard({
                        nickname: "WebDev",
                        message: "Halo mase, overlaynya sudah aktif! 🔥",
                        profilePictureUrl: "coba.png"
                    });
                }
            }
            // ... Kode pengecekan testFunc lainnya ...
            else if (testFuncName === 'showMilestone' && typeof iframe.contentWindow[testFuncName] === 'function') {
                const savedMilestone = JSON.parse(localStorage.getItem('saved_gift_milestone')) || {
                    title: 'Target Singa Terbang!', giftName: 'Lion', targetValue: 100, currentValue: 35
                };

                // Kirim langsung ke fungsi JavaScript di dalam file HTML overlay
                iframe.contentWindow[testFuncName](
                    savedMilestone.currentValue,
                    savedMilestone.targetValue,
                    'https://cdn-icons-png.flaticon.com/512/3112/3112946.png', // Icon default tiruan
                    savedMilestone.title
                );
            }
            // Fallback default
            else if (typeof iframe.contentWindow[testFuncName] === 'function') {
                iframe.contentWindow[testFuncName](rvDefaultTestData);
            }

        } else {
            const fallbackData = {
                nickname: "Sultan_Join",
                uniqueId: "sultan_parepare",
                user: "sultan_parepare",
                profilePictureUrl: "https://www.w3schools.com/howto/img_avatar.png",
                giftName: "Casino Dice",
                diamondCount: 100,
                repeatCount: 1
            };
            if (iframe.contentWindow) {
                iframe.contentWindow.dispatchEvent(new CustomEvent("previewJoin", { detail: fallbackData }));
                iframe.contentWindow.dispatchEvent(new CustomEvent("previewGift", { detail: fallbackData }));
            }
            if (typeof showToast === "function") {
                showToast("Memuat Preview " + themeObj.name);
            }
        }
    };


    if (currentModalKey === 'musicoverlay') {
        iframe.style.visibility = 'hidden';
    }


    // 🔥 PERBAIKAN 3: Jalankan pengisian src di paling akhir setelah event handler siap sepenuhnya
    iframe.src = finalRenderUrl;
}

// 4. Fungsi Menutup Modal Pop-up
function closeOverlayModal() {
    document.getElementById('rv-overlay-modal').style.display = 'none';
    document.getElementById('modal-overlay-preview').src = 'about:blank';
}

// 5. Proses Eksekusi Copy Link dari Modal
function executeApplyAndCopy() {
    if (!currentSelectedThemeUrl) {
        if (typeof showToast === "function") showToast("Silakan pilih tema terlebih dahulu!");
        return;
    }

    const finalSelect = document.getElementById(currentOldSelectId);
    if (finalSelect) {
        finalSelect.value = currentSelectedThemeUrl;
    }

    let baseUrl = window.location.origin;
    if (baseUrl.includes('localhost') === false && currentModalKey === 'hardware') {
        baseUrl = 'http://localhost:3000';
    }

    let fullUrl = baseUrl + currentSelectedThemeUrl;

    if (currentModalKey === 'hardware' && cachedHardwareSpecs && !cachedHardwareSpecs.error) {
        fullUrl += `?cpu=${encodeURIComponent(cachedHardwareSpecs.cpu)}&gpu=${encodeURIComponent(cachedHardwareSpecs.gpu)}&ram=${cachedHardwareSpecs.ram}`;
    }

    if (currentModalKey === 'followergoal') {
        const modalInput = document.getElementById('modalTargetFollower');
        const targetValue = modalInput ? modalInput.value : 50;
        fullUrl += `?target=${targetValue}`;
    }

    if (currentModalKey === 'brandtext') {
        // Gabungkan array teks menjadi satu string dipisah karakter '|'
        const combinedTexts = modalBrandTextsArray.length > 0 ? modalBrandTextsArray.join('|') : "PROMO STREAMINGAN";
        fullUrl += `?texts=${encodeURIComponent(combinedTexts)}`;

        // Sinkronkan ke tampilan luar/halaman utama setelah modal ditutup
        const mainList = document.getElementById('list-brand-text');
        if (mainList) {
            if (modalBrandTextsArray.length === 0) {
                mainList.innerHTML = `<span style="color: #666; font-style: italic;">Belum ada teks ditambahkan...</span>`;
            } else {
                mainList.innerHTML = "";
                modalBrandTextsArray.forEach(t => {
                    mainList.innerHTML += `<div class="brand-badge-text" style="display:inline-block; background:#222; padding:2px 6px; margin:2px; border-radius:4px; font-size:11px;">${t}</div> `;
                });
            }
        }
    }

    // Logika pemrosesan url untuk key 'social' di dalam fungsi executeApplyAndCopy
    if (currentModalKey === 'social') {
        const socialData = {
            ig: document.getElementById('modal-social-ig').value.trim(),
            tt: document.getElementById('modal-social-tt').value.trim(),
            yt: document.getElementById('modal-social-yt').value.trim(),
            dc: document.getElementById('modal-social-dc').value.trim(),
            duration: document.getElementById('modal-social-duration').value,
            enabled: document.getElementById('modal-toggle-social').checked
        };

        // KUNCI UTAMA: Simpan objek data ke localStorage agar tidak hilang saat di-refresh/close
        localStorage.setItem('saved_social_data', JSON.stringify(socialData));

        // Buat query parameters untuk URL overlay browser source OBS / TikTok Live Studio
        fullUrl += `?ig=${encodeURIComponent(socialData.ig)}&tt=${encodeURIComponent(socialData.tt)}&yt=${encodeURIComponent(socialData.yt)}&dc=${encodeURIComponent(socialData.dc)}&duration=${socialData.duration}&enabled=${socialData.enabled}`;

        // Sinkronisasi data ke elemen tampilan utama (luar modal) jika kamu membutuhkannya
        const nativeSelect = document.getElementById(currentOldSelectId);
        const nativeCheckbox = document.getElementById('toggle-social');
        const nativeStatusText = document.getElementById('social-status');

        if (nativeCheckbox) nativeCheckbox.checked = socialData.enabled;
        if (nativeStatusText) {
            nativeStatusText.innerText = socialData.enabled ? "ON" : "OFF";
            nativeStatusText.className = socialData.enabled ? "network-status active" : "network-status"; // Menyesuaikan style luar kamu
        }
    }

    // Logika pemrosesan url untuk key 'dockgift'
    if (currentModalKey === 'dockgift') {
        const savedGiftBenefits = JSON.parse(localStorage.getItem('saved_gift_benefits')) || [];
        // Kita encode array object menjadi string base64 atau JSON String agar aman di URL parameter
        const encodedData = encodeURIComponent(JSON.stringify(savedGiftBenefits));
        fullUrl += `?gifts=${encodedData}`;
    }

    // Logika pemrosesan url untuk key 'Milestone'
    if (currentModalKey === 'milestone') {
        const savedMilestone = JSON.parse(localStorage.getItem('saved_gift_milestone')) || {
            title: 'Target', giftName: 'Lion', targetValue: 100, currentValue: 0
        };
        fullUrl += `?title=${encodeURIComponent(savedMilestone.title)}&gift=${encodeURIComponent(savedMilestone.giftName)}&target=${savedMilestone.targetValue}&current=${savedMilestone.currentValue}`;
    }

    // Copy link tanpa trigger toast alert di sini, 
    // agar tidak dobel dengan notifikasi utama dari tombol Apply
    if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(fullUrl).then(() => {
            // Baris showToast dihapus dari sini
            console.log("Link berhasil disalin ke clipboard");
        }).catch(() => {
            fallbackCopyTextHelper(fullUrl);
        });
    } else {
        fallbackCopyTextHelper(fullUrl);
    }

    // Lanjut ke penutupan modal
    closeOverlayModal();
}

function fallbackCopyTextHelper(text) {
    const textArea = document.createElement("textarea");
    textArea.value = text;
    textArea.style.position = "fixed";
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
        document.execCommand('copy');
        if (typeof showToast === "function") showToast("Link Overlay Berhasil Di-copy!");
    } catch (err) {
        if (typeof showToast === "function") showToast("Gagal menyalin link otomatis.");
    }
    document.body.removeChild(textArea);
}

// ====================================================================
// ⚡ MASTER OVERLAY INTERCEPTOR: INSTANT PREVIEW UNTUK SEMUA TEMA ⚡
// ====================================================================
// Otomatis membajak & mempercepat preview 20+ tema Chatbox & DockChat sekaligus!

function superBypassTheme(iframe) {
    try {
        const iframeWin = iframe.contentWindow;
        if (!iframeWin) return;

        // 1. Ambil nama fungsi pengetesan (bawaan dari property testFunc: 'showChat')
        // Kita juga siapkan fallback ke 'triggerDisplayChatCard' untuk tema kapsul hitam kemarin
        const fungsiRenderUtama = iframeWin.showChat || iframeWin.triggerDisplayChatCard || iframeWin.soundChat;

        // 2. Langsung tebas interval bawaan di dalam file tema yang bikin nunggu 4 detik
        if (iframeWin.previewInterval) {
            clearInterval(iframeWin.previewInterval);
        }

        // 3. Jika fungsi targetnya ketemu, eksekusi pemaksaan instan!
        if (typeof fungsiRenderUtama === 'function') {
            const listPesanDummy = [
                "Wih mantap, tampilannya langsung berubah instan brow! 🔥",
                "Tes chat masuk, aman lancar jaya sepertinya.",
                "Senggol dong boskuuu 😎✨",
                "Gokil, efek animasi temanya jalan smooth bgt!"
            ];

            // Generator chat dummy terpusat
            const kirimChatInstan = () => {
                const randomPesan = listPesanDummy[Math.floor(Math.random() * listPesanDummy.length)];

                // Kirim data dengan struktur komplit (antisipasi perbedaan variabel di tiap tema)
                fungsiRenderUtama({
                    nickname: "WebDev",
                    user: "Yusrianto lana",
                    message: randomPesan,
                    profilePictureUrl: 'coba.png'
                });
            };

            // 🔥 EKSEKUSI 0 DETIK: Begitu klik ganti tema, chat pertama LANGSUNG JRET MUNCUL!
            kirimChatInstan();

            // 4. Daftarkan ulang interval baru agar chat tiruan berikutnya tetap bergulir tiap 4 detik
            iframeWin.previewInterval = setInterval(kirimChatInstan, 4000);

            console.log(`⚙️ [WEBDEV ENGINE] Sukses memotong delay tema: ${iframe.src}`);
        }
    } catch (err) {
        // Mencegah error jika iframe belum siap dibaca memorinya
        console.warn("Sistem sedang mempersiapkan iframe...", err);
    }
}

// 🎯 MONITORING GLOBAL: Intip setiap kali ada perpindahan tema di Chatbox maupun Dockchat
window.addEventListener('load', function (e) {
    if (e.target && e.target.tagName === 'IFRAME') {
        // Beri sedikit jeda mikro (50ms) agar DOM di dalam iframe ter-render sempurna lebih dulu
        setTimeout(() => superBypassTheme(e.target), 50);
    }
}, true); // Menggunakan Capture Phase agar event load dari elemen <iframe> bisa tertangkap dari pusat

// 🎯 ANTISIPASI: Jalankan langsung ke iframe yang sudah terlanjur nempel saat halaman di-refresh
document.querySelectorAll('iframe').forEach(iframe => {
    iframe.addEventListener('load', () => setTimeout(() => superBypassTheme(iframe), 50));
    setTimeout(() => superBypassTheme(iframe), 50);
});